import React from 'react';
import { motion } from 'framer-motion';
import { Compass, Zap, BookOpen, Leaf, Droplets, Recycle, Library, MapPin } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const placeholderCategories = [
  { name: "Energy Saving", icon: <Zap className="w-12 h-12 text-yellow-400 mx-auto mb-3" />, description: "Discover tips to reduce your energy consumption." },
  { name: "Sustainable Swaps", icon: <Compass className="w-12 h-12 text-blue-400 mx-auto mb-3" />, description: "Find eco-friendly alternatives for everyday products." },
  { name: "Learn & Grow", icon: <BookOpen className="w-12 h-12 text-purple-400 mx-auto mb-3" />, description: "Expand your knowledge on environmental topics." },
  { name: "Go Green", icon: <Leaf className="w-12 h-12 text-green-500 mx-auto mb-3" />, description: "Explore plant-based living and gardening." },
  { name: "Water Wise", icon: <Droplets className="w-12 h-12 text-sky-500 mx-auto mb-3" />, description: "Tips for conserving water in daily life." },
  { name: "Reduce & Reuse", icon: <Recycle className="w-12 h-12 text-orange-500 mx-auto mb-3" />, description: "Learn to minimize waste and recycle effectively." },
];

const imageGallery = [
  { srcKey: "forest-bathing", alt: "Lush green forest with sunlight filtering through trees", description: "Forest Bathing" },
  { srcKey: "gardening-hands", alt: "Close-up of hands planting a small seedling in rich soil", description: "Gardening" },
  { srcKey: "reusable-bags", alt: "Colorful reusable shopping bags filled with fresh produce", description: "Sustainable Shopping" },
  { srcKey: "solar-panels", alt: "Solar panels on a modern house rooftop", description: "Renewable Energy" },
  { srcKey: "city-bicycle", alt: "Bicycle leaning against a wall in a city", description: "Eco-Friendly Commute" },
  { srcKey: "community-garden", alt: "Community garden with people tending to plants", description: "Local Initiatives" },
];

const greenLibraryArticles = [
  { id: 1, title: "The Ultimate Guide to Composting at Home", category: "Waste Reduction", date: "2025-05-20", summary: "Learn how to turn your kitchen scraps into nutrient-rich compost for your garden...", icon: <Recycle className="w-6 h-6 text-orange-500 mr-2" /> },
  { id: 2, title: "10 Easy Ways to Save Water Every Day", category: "Water Conservation", date: "2025-05-18", summary: "Simple habits that can make a big difference in your water consumption and bills...", icon: <Droplets className="w-6 h-6 text-sky-500 mr-2" /> },
  { id: 3, title: "Understanding Your Carbon Footprint", category: "Climate Action", date: "2025-05-15", summary: "What is a carbon footprint and how can you reduce yours? A beginner's guide...", icon: <Zap className="w-6 h-6 text-yellow-400 mr-2" /> },
];

const localEvents = [
    { id: 1, name: "Community Cleanup Day", location: "Greenwood Park", date: "2025-06-15", description: "Join us for a park cleanup event. Gloves and bags provided!" },
    { id: 2, name: "Farmer's Market Opening", location: "Town Square", date: "2025-06-01", description: "Support local farmers and get fresh, seasonal produce." },
];


const ExploreScreen = () => {
  return (
    <div className="space-y-10">
      <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600 dark:from-blue-400 dark:to-purple-500">
        Explore Eco Ideas
      </h1>
      <p className="text-lg text-slate-600 dark:text-slate-300">
        Discover new ways to make a positive impact. Dive into categories, get inspired by our gallery, and explore local green initiatives.
      </p>
      
      <section>
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Categories</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {placeholderCategories.map((category, index) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
              className="p-6 rounded-xl bg-white dark:bg-slate-800 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 glassmorphism"
            >
              {category.icon}
              <h3 className="text-xl font-semibold text-center text-slate-800 dark:text-slate-100 mb-2">{category.name}</h3>
              <p className="text-sm text-center text-slate-500 dark:text-slate-400 h-12">{category.description}</p>
              <div className="mt-4 text-center">
                 <Button variant="outline" size="sm" className="text-primary border-primary hover:bg-primary/10 dark:text-green-400 dark:border-green-400 dark:hover:bg-green-400/10">
                  Explore Now
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Inspiration Gallery</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1, duration: 0.4 }} className="relative rounded-lg overflow-hidden shadow-md group aspect-video md:aspect-square">
            <img  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" alt={imageGallery[0].alt} src="https://images.unsplash.com/photo-1694388001616-1176f534d72f" />
            <div className="absolute inset-0 bg-black/40 flex items-end p-3"> <p className="text-white text-sm font-semibold">{imageGallery[0].description}</p> </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.15, duration: 0.4 }} className="relative rounded-lg overflow-hidden shadow-md group aspect-video md:aspect-square">
            <img  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" alt={imageGallery[1].alt} src="https://images.unsplash.com/photo-1675270714610-11a5cadcc7b3" />
            <div className="absolute inset-0 bg-black/40 flex items-end p-3"> <p className="text-white text-sm font-semibold">{imageGallery[1].description}</p> </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2, duration: 0.4 }} className="relative rounded-lg overflow-hidden shadow-md group aspect-video md:aspect-square">
            <img  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" alt={imageGallery[2].alt} src="https://images.unsplash.com/photo-1675023112817-52b789fd2ef0" />
            <div className="absolute inset-0 bg-black/40 flex items-end p-3"> <p className="text-white text-sm font-semibold">{imageGallery[2].description}</p> </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.25, duration: 0.4 }} className="relative rounded-lg overflow-hidden shadow-md group aspect-video md:aspect-square">
            <img  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" alt={imageGallery[3].alt} src="https://images.unsplash.com/photo-1675270714610-11a5cadcc7b3" />
            <div className="absolute inset-0 bg-black/40 flex items-end p-3"> <p className="text-white text-sm font-semibold">{imageGallery[3].description}</p> </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.3, duration: 0.4 }} className="relative rounded-lg overflow-hidden shadow-md group aspect-video md:aspect-square">
            <img  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" alt={imageGallery[4].alt} src="https://images.unsplash.com/photo-1675023112817-52b789fd2ef0" />
            <div className="absolute inset-0 bg-black/40 flex items-end p-3"> <p className="text-white text-sm font-semibold">{imageGallery[4].description}</p> </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.35, duration: 0.4 }} className="relative rounded-lg overflow-hidden shadow-md group aspect-video md:aspect-square">
            <img  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" alt={imageGallery[5].alt} src="https://images.unsplash.com/photo-1544212408-c711b7c19b92" />
            <div className="absolute inset-0 bg-black/40 flex items-end p-3"> <p className="text-white text-sm font-semibold">{imageGallery[5].description}</p> </div>
          </motion.div>
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200 flex items-center">
          <Library className="w-7 h-7 mr-2 text-green-600 dark:text-green-400" /> Green Library
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {greenLibraryArticles.map((article, index) => (
            <motion.div
              key={article.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.1, duration: 0.3 }}
            >
              <Card className="h-full flex flex-col bg-white dark:bg-slate-800 shadow-lg hover:shadow-xl transition-shadow transform hover:-translate-y-1">
                <CardHeader>
                  <div className="flex items-center mb-2">
                    {article.icon}
                    <CardTitle className="text-lg">{article.title}</CardTitle>
                  </div>
                  <CardDescription className="text-xs">{article.category} - {article.date}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-sm text-slate-600 dark:text-slate-300">{article.summary}</p>
                </CardContent>
                <div className="p-4 pt-0">
                  <Button variant="link" className="text-primary dark:text-green-400 p-0">Read More &rarr;</Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200 flex items-center">
            <MapPin className="w-7 h-7 mr-2 text-red-500 dark:text-red-400" /> Local Green Events
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {localEvents.map((event, index) => (
                <motion.div
                    key={event.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 + index * 0.1, duration: 0.3 }}
                >
                    <Card className="bg-white dark:bg-slate-800 shadow-lg hover:shadow-xl transition-shadow">
                        <CardHeader>
                            <CardTitle className="text-lg">{event.name}</CardTitle>
                            <CardDescription className="text-xs">{event.location} - {event.date}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-slate-600 dark:text-slate-300">{event.description}</p>
                        </CardContent>
                        <div className="p-4 pt-0">
                            <Button variant="outline" size="sm">View Details</Button>
                        </div>
                    </Card>
                </motion.div>
            ))}
        </div>
        {localEvents.length === 0 && <p className="text-slate-500 dark:text-slate-400">No local events listed currently. Check back soon!</p>}
      </section>

      <div className="text-center mt-12 py-8 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/30 dark:to-emerald-900/30 rounded-lg">
        <Leaf size={36} className="mx-auto text-primary mb-3" />
        <p className="text-lg text-slate-700 dark:text-slate-200">
          We're constantly adding new content and features. Stay tuned for more ways to make a difference!
        </p>
      </div>
    </div>
  );
};

export default ExploreScreen;