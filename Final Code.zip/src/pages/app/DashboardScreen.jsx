import React from 'react';
import { motion } from 'framer-motion';
import { BarChartBig, TrendingUp, Target, Award, Users, Crown } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const DashboardScreen = () => {
  const stats = [
    { label: "Tasks Completed", value: "12", icon: <BarChartBig className="w-8 h-8 text-primary" />, color: "green" },
    { label: "Impact Score", value: "1.35", icon: <TrendingUp className="w-8 h-8 text-blue-500" />, color: "blue" },
    { label: "Current Streak", value: "3 Days", icon: <Target className="w-8 h-8 text-yellow-500" />, color: "yellow" },
  ];

  const scoreboardData = [
    { rank: 1, name: "Alex Green", score: 1500, avatarKey: "alex-green", icon: <Crown className="w-5 h-5 text-yellow-400" /> },
    { rank: 2, name: "Bella Bloom", score: 1350, avatarKey: "bella-bloom" },
    { rank: 3, name: "Carlos River", score: 1200, avatarKey: "carlos-river" },
    { rank: 4, name: "You", score: 1050, avatarKey: "current-user", isCurrentUser: true },
    { rank: 5, name: "Diana Sky", score: 900, avatarKey: "diana-sky" },
  ];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-yellow-500 to-orange-600 dark:from-yellow-400 dark:to-orange-500">
        Your Dashboard
      </h1>
      
      <section>
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Quick Stats</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1, duration: 0.3 }}
              className={`p-6 rounded-xl bg-white dark:bg-slate-800 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 border-l-4 border-${stat.color}-500 glassmorphism`}
            >
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">{stat.label}</h3>
                {stat.icon}
              </div>
              <p className={`text-3xl font-bold text-${stat.color}-600 dark:text-${stat.color}-400`}>{stat.value}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.3 }}
        className="p-6 rounded-xl bg-white dark:bg-slate-800 shadow-lg glassmorphism"
      >
        <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-3">Overall Progress</h2>
        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-6">
          <motion.div 
            className="bg-gradient-to-r from-primary to-emerald-500 h-6 rounded-full flex items-center justify-center text-xs font-medium text-white"
            initial={{ width: '0%'}}
            animate={{ width: '65%'}}
            transition={{ delay: 0.4, duration: 0.8, type: "spring" }}
          >
            65%
          </motion.div>
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">This is a placeholder progress bar. Actual data will be shown here.</p>
      </motion.div>

      <section>
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200 flex items-center">
          <Award className="w-7 h-7 mr-2 text-amber-500" /> Scoreboard
        </h2>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.3 }}
          className="bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden glassmorphism"
        >
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {scoreboardData.map((user, index) => (
              <motion.li
                key={user.rank}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.05, duration: 0.3 }}
                className={`flex items-center justify-between p-4 transition-colors ${user.isCurrentUser ? 'bg-green-100 dark:bg-green-900/50' : 'hover:bg-slate-50 dark:hover:bg-slate-700/50'}`}
              >
                <div className="flex items-center">
                  <span className={`text-lg font-semibold w-8 text-center ${user.rank <= 3 ? 'text-amber-500' : 'text-slate-500 dark:text-slate-400'}`}>
                    {user.rank}
                  </span>
                  <Avatar className="w-10 h-10 ml-3 mr-3 border-2 border-slate-300 dark:border-slate-600">
                    <AvatarImage src={`https://source.unsplash.com/random/100x100/?portrait,person,${user.avatarKey}`} alt={user.name} />
                    <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <span className={`font-medium ${user.isCurrentUser ? 'text-primary dark:text-green-400' : 'text-slate-700 dark:text-slate-200'}`}>{user.name}</span>
                  {user.icon && <span className="ml-1">{user.icon}</span>}
                </div>
                <span className={`font-semibold text-lg ${user.isCurrentUser ? 'text-primary dark:text-green-400' : 'text-slate-600 dark:text-slate-300'}`}>{user.score} pts</span>
              </motion.li>
            ))}
          </ul>
        </motion.div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-3 text-center">
          Scoreboard is for illustrative purposes. Compete and climb the ranks!
        </p>
      </section>
      
      <div className="text-center mt-10">
        <Users size={48} className="mx-auto text-primary mb-3" />
        <p className="text-slate-600 dark:text-slate-300">Join challenges, earn points, and see your name on top!</p>
      </div>
    </div>
  );
};

export default DashboardScreen;