import React, { useState, useEffect } from 'react';
import TaskCard from '@/components/TaskCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuCheckboxItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { PlusCircle, Filter, Leaf, CheckCircle, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';

const MOCK_TASKS_STORAGE_KEY = 'greenSprintTasks';
const TASK_CATEGORIES = ["Swaps", "Advocacy", "Lifestyle", "Energy", "Waste Reduction", "Water Conservation", "Community"];

const SprintQueueScreen = () => {
  const [tasks, setTasks] = useState([]);
  const [isAddTaskDialogOpen, setIsAddTaskDialogOpen] = useState(false);
  const [newTask, setNewTask] = useState({ title: '', category: '', impact: '', time: '' });
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');

  const { toast } = useToast();

  useEffect(() => {
    const storedTasks = JSON.parse(localStorage.getItem(MOCK_TASKS_STORAGE_KEY) || '[]');
    setTasks(storedTasks);
  }, []);

  const updateStoredTasks = (updatedTasks) => {
    localStorage.setItem(MOCK_TASKS_STORAGE_KEY, JSON.stringify(updatedTasks));
    setTasks(updatedTasks);
  };

  const handleToggleComplete = (taskId) => {
    const updatedTasks = tasks.map(task =>
      task.id === taskId ? { ...task, completed: !task.completed } : task
    );
    updateStoredTasks(updatedTasks);
    const updatedTask = updatedTasks.find(t => t.id === taskId);
    toast({
      title: `Task ${updatedTask.completed ? "Completed" : "Marked Incomplete"}!`,
      description: `"${updatedTask.title}" status updated.`,
      variant: updatedTask.completed ? "default" : "destructive",
      className: updatedTask.completed ? "bg-green-500 border-green-500 text-white" : "bg-yellow-500 border-yellow-500 text-white"
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTask(prev => ({ ...prev, [name]: value }));
  };

  const handleCategoryChange = (value) => {
    setNewTask(prev => ({ ...prev, category: value }));
  };

  const handleAddTask = () => {
    if (!newTask.title || !newTask.category || !newTask.impact || !newTask.time) {
      toast({
        title: "Missing Information",
        description: "Please fill out all fields to add a task.",
        variant: "destructive",
      });
      return;
    }
    const taskToAdd = {
      id: String(Date.now()),
      ...newTask,
      impact: parseFloat(newTask.impact),
      time: parseInt(newTask.time),
      completed: false,
    };
    const updatedTasks = [taskToAdd, ...tasks];
    updateStoredTasks(updatedTasks);
    setNewTask({ title: '', category: '', impact: '', time: '' });
    setIsAddTaskDialogOpen(false);
    toast({
      title: "Task Added!",
      description: `"${taskToAdd.title}" has been added to your sprint.`,
      className: "bg-green-500 border-green-500 text-white"
    });
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const filteredTasks = tasks.filter(task => {
    const statusMatch = filterStatus === 'all' || (filterStatus === 'completed' && task.completed) || (filterStatus === 'active' && !task.completed);
    const categoryMatch = filterCategory === 'all' || task.category === filterCategory;
    return statusMatch && categoryMatch;
  });
  
  const activeTasks = filteredTasks.filter(task => !task.completed);
  const completedTasks = filteredTasks.filter(task => task.completed);

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div className="flex items-center mb-4 sm:mb-0">
          <Leaf size={36} className="mr-3 text-primary" />
          <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-green-500 to-emerald-700 dark:from-green-400 dark:to-emerald-600">
            Your Sprint
          </h1>
        </div>
        <div className="flex space-x-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="bg-secondary hover:bg-secondary/80">
                <Filter size={16} className="mr-2" /> Filter ({filterStatus !== 'all' || filterCategory !== 'all' ? 'Active' : 'None'})
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56">
              <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuCheckboxItem checked={filterStatus === 'all'} onCheckedChange={() => setFilterStatus('all')}>All</DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem checked={filterStatus === 'active'} onCheckedChange={() => setFilterStatus('active')}>Active</DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem checked={filterStatus === 'completed'} onCheckedChange={() => setFilterStatus('completed')}>Completed</DropdownMenuCheckboxItem>
              <DropdownMenuLabel>Filter by Category</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuCheckboxItem checked={filterCategory === 'all'} onCheckedChange={() => setFilterCategory('all')}>All Categories</DropdownMenuCheckboxItem>
              {TASK_CATEGORIES.map(cat => (
                <DropdownMenuCheckboxItem key={cat} checked={filterCategory === cat} onCheckedChange={() => setFilterCategory(cat)}>{cat}</DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Button size="sm" className="bg-gradient-to-r from-primary to-emerald-600 hover:from-primary/90 hover:to-emerald-600/90 text-white" onClick={() => setIsAddTaskDialogOpen(true)}>
            <PlusCircle size={16} className="mr-2" /> Add Task
          </Button>
        </div>
      </header>

      <Dialog open={isAddTaskDialogOpen} onOpenChange={setIsAddTaskDialogOpen}>
        <DialogContent className="sm:max-w-[425px] glassmorphism">
          <DialogHeader>
            <DialogTitle>Add New Eco Task</DialogTitle>
            <DialogDescription>
              Describe the task you want to add to your sprint. Every little action counts!
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="title" className="text-right">Title</Label>
              <Input id="title" name="title" value={newTask.title} onChange={handleInputChange} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="category" className="text-right">Category</Label>
              <Select onValueChange={handleCategoryChange} defaultValue={newTask.category}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {TASK_CATEGORIES.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="impact" className="text-right">Impact (pts)</Label>
              <Input id="impact" name="impact" type="number" value={newTask.impact} onChange={handleInputChange} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="time" className="text-right">Time (min)</Label>
              <Input id="time" name="time" type="number" value={newTask.time} onChange={handleInputChange} className="col-span-3" />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="secondary">Cancel</Button>
            </DialogClose>
            <Button type="button" onClick={handleAddTask}>Add Task</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {activeTasks.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Active Tasks ({activeTasks.length})</h2>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            <AnimatePresence>
              {activeTasks.map(task => (
                <TaskCard key={task.id} task={task} onToggleComplete={handleToggleComplete} />
              ))}
            </AnimatePresence>
          </motion.div>
        </section>
      )}
      
      {activeTasks.length === 0 && filteredTasks.length > 0 && filterStatus !== 'completed' && (
         <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8 px-4 bg-green-50 dark:bg-green-900/20 rounded-lg"
        >
          <CheckCircle size={48} className="mx-auto text-primary mb-3" />
          <h2 className="text-2xl font-semibold text-primary mb-2">All active tasks completed!</h2>
          <p className="text-slate-600 dark:text-slate-300">Great job! Check your completed tasks or add new ones.</p>
        </motion.div>
      )}

      {filteredTasks.length === 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8 px-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg"
        >
          <Zap size={48} className="mx-auto text-yellow-500 mb-3" />
          <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-200 mb-2">No tasks match your filters!</h2>
          <p className="text-slate-600 dark:text-slate-300">Try adjusting your filters or add new tasks to your sprint.</p>
        </motion.div>
      )}
      

      {completedTasks.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Completed Tasks ({completedTasks.length})</h2>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            <AnimatePresence>
              {completedTasks.map(task => (
                <TaskCard key={task.id} task={task} onToggleComplete={handleToggleComplete} />
              ))}
            </AnimatePresence>
          </motion.div>
        </section>
      )}
    </div>
  );
};

export default SprintQueueScreen;