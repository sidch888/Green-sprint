import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import BottomNavBar from '@/components/BottomNavBar';
import { motion, AnimatePresence } from 'framer-motion';

const MainAppLayout = () => {
  const location = useLocation();

  return (
    <div className="flex justify-center min-h-screen bg-slate-200 dark:bg-slate-950">
      <div 
        className="w-full max-w-md flex flex-col min-h-screen bg-slate-100 dark:bg-slate-900 shadow-2xl"
        style={{
          // iPhone 12 Pro dimensions: 390x844 (approx)
          // We'll use max-width for responsiveness but give it a common phone width.
          // The height will be handled by min-h-screen.
        }}
      >
        <main className="flex-grow px-4 py-6 pb-24 md:pb-6 overflow-y-auto"> {/* Added padding-bottom for mobile nav */}
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="w-full"
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
        <BottomNavBar />
      </div>
    </div>
  );
};

export default MainAppLayout;