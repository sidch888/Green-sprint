import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Search, BarChart2, User, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const navItems = [
  { path: '/app/sprint', icon: Home, label: 'Sprint' },
  { path: '/app/explore', icon: Sparkles, label: 'Explore' },
  { path: '/app/dashboard', icon: BarChart2, label: 'Dashboard' },
  { path: '/app/profile', icon: User, label: 'Profile' },
];

const BottomNavBar = () => {
  return (
    <motion.nav 
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', stiffness: 100, damping: 20 }}
      className="sticky bottom-0 left-0 right-0 h-16 bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 shadow- ऊपर-lg glassmorphism z-50 w-full" // Ensure it spans full width of its container
    >
      <div className="flex justify-around items-center h-full">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              cn(
                'flex flex-col items-center justify-center text-xs w-1/4 h-full transition-colors duration-200',
                isActive ? 'text-primary dark:text-green-400' : 'text-slate-500 dark:text-slate-400 hover:text-primary dark:hover:text-green-400'
              )
            }
          >
            {({ isActive }) => (
              <>
                <item.icon size={24} strokeWidth={isActive ? 2.5 : 2} />
                <span className={cn("mt-0.5", isActive ? "font-semibold" : "font-normal")}>{item.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="active-nav-indicator"
                    className="absolute bottom-0 h-1 w-10 bg-primary dark:bg-green-400 rounded-t-full"
                    initial={false}
                    animate={{ opacity: 1 }}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
              </>
            )}
          </NavLink>
        ))}
      </div>
    </motion.nav>
  );
};

export default BottomNavBar;