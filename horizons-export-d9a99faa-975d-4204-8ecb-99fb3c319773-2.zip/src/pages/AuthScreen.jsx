import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Leaf, LogIn, UserPlus, SkipForward } from 'lucide-react';
import GoogleLogo from '@/components/icons/GoogleLogo';
import AppleLogo from '@/components/icons/AppleLogo';
import DiscordLogo from '@/components/icons/DiscordLogo';
import { useToast } from "@/components/ui/use-toast";


const AuthScreen = ({ onAuthSuccess }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSignUp, setIsSignUp] = useState(false); // false for Login, true for Sign Up options
  const [showSocialOptions, setShowSocialOptions] = useState(false);

  const handleSkip = () => {
    // For skip, we can set a temporary auth status or a specific flag
    // For simplicity, let's treat skip as a successful auth for now to enter the app
    onAuthSuccess(); 
    navigate('/app');
  };

  const handleLogin = () => {
    // Placeholder for actual login logic
    toast({ title: "Login Clicked", description: "Login functionality to be implemented." });
    // onAuthSuccess(); // Call this on successful login
    // navigate('/app');
  };

  const handleShowSignUpOptions = () => {
    setIsSignUp(true);
    setShowSocialOptions(true);
  };
  
  const handleShowLogin = () => {
    setIsSignUp(false);
    setShowSocialOptions(false);
  };

  const handleSocialSignUp = (provider) => {
    // Placeholder for actual social sign-up logic
    toast({ title: `Sign up with ${provider}`, description: `${provider} sign-up to be implemented.` });
    // onAuthSuccess(); // Call this on successful sign-up
    // navigate('/app');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center min-h-screen p-6 bg-gradient-to-br from-slate-100 to-stone-200 dark:from-slate-900 dark:to-stone-800"
    >
      <div className="w-full max-w-sm p-8 bg-white dark:bg-slate-800 rounded-xl shadow-2xl glassmorphism">
        <div className="flex justify-center mb-6">
          <Leaf size={64} className="text-primary drop-shadow-lg" />
        </div>
        <h1 className="text-3xl font-bold text-center mb-2 text-slate-800 dark:text-slate-100">
          {showSocialOptions ? "Join Green Sprint" : "Welcome Back!"}
        </h1>
        <p className="text-center text-slate-600 dark:text-slate-300 mb-8">
          {showSocialOptions ? "Create an account to save your progress." : "Login to continue your eco journey."}
        </p>

        {!showSocialOptions && (
          <motion.div 
            initial={{ opacity: 0, y:10 }}
            animate={{ opacity: 1, y:0 }}
            transition={{ duration: 0.3 }}
            className="space-y-4 mb-6"
          >
            <div>
              <Label htmlFor="email" className="text-slate-700 dark:text-slate-200">Email</Label>
              <Input id="email" type="email" placeholder="you@example.com" className="mt-1 bg-white/80 dark:bg-slate-700/80" />
            </div>
            <div>
              <Label htmlFor="password"className="text-slate-700 dark:text-slate-200">Password</Label>
              <Input id="password" type="password" placeholder="••••••••" className="mt-1 bg-white/80 dark:bg-slate-700/80" />
            </div>
            <Button onClick={handleLogin} className="w-full bg-gradient-to-r from-primary to-emerald-600 hover:from-primary/90 hover:to-emerald-600/90 text-white">
              <LogIn size={18} className="mr-2" /> Login
            </Button>
            <p className="text-sm text-center text-slate-500 dark:text-slate-400">
              Don't have an account?{' '}
              <button onClick={handleShowSignUpOptions} className="font-medium text-primary hover:underline">
                Sign Up
              </button>
            </p>
          </motion.div>
        )}

        {showSocialOptions && (
          <motion.div 
            initial={{ opacity: 0, y:10 }}
            animate={{ opacity: 1, y:0 }}
            transition={{ duration: 0.3 }}
            className="space-y-3 mb-6"
          >
            <p className="text-sm font-medium text-center text-slate-600 dark:text-slate-300 mb-3">Sign up with:</p>
            <Button onClick={() => handleSocialSignUp('Google')} variant="outline" className="w-full justify-start">
              <GoogleLogo className="w-5 h-5 mr-3" /> Continue with Google
            </Button>
            <Button onClick={() => handleSocialSignUp('Apple')} variant="outline" className="w-full justify-start">
              <AppleLogo className="w-5 h-5 mr-3" /> Continue with Apple
            </Button>
            <Button onClick={() => handleSocialSignUp('Discord')} variant="outline" className="w-full justify-start">
              <DiscordLogo className="w-5 h-5 mr-3" /> Continue with Discord
            </Button>
             <p className="text-sm text-center text-slate-500 dark:text-slate-400 pt-2">
              Already have an account?{' '}
              <button onClick={handleShowLogin} className="font-medium text-primary hover:underline">
                Login
              </button>
            </p>
          </motion.div>
        )}
        
        <div className="mt-6 text-center">
          <Button onClick={handleSkip} variant="link" className="text-slate-500 dark:text-slate-400 hover:text-primary">
            <SkipForward size={16} className="mr-2" /> Skip for now
          </Button>
        </div>
      </div>
      <footer className="absolute bottom-4 text-center w-full text-slate-500 dark:text-slate-400 text-xs">
        <p>&copy; {new Date().getFullYear()} Green Sprint. Small actions, big impact.</p>
      </footer>
    </motion.div>
  );
};

export default AuthScreen;