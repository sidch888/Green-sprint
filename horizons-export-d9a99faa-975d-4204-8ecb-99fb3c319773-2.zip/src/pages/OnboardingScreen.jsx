import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle, Zap, Users } from 'lucide-react';

const OnboardingScreen = ({ onComplete }) => {
  const navigate = useNavigate();

  const handleCompleteOnboarding = () => {
    onComplete();
    navigate('/auth'); 
  };

  const features = [
    { icon: <CheckCircle className="w-10 h-10 text-primary" />, title: "Track Eco-Actions", description: "Log your sustainable habits and see your progress." },
    { icon: <Zap className="w-10 h-10 text-yellow-400" />, title: "Discover New Challenges", description: "Find inspiration with new eco-challenges." },
    { icon: <Users className="w-10 h-10 text-blue-400" />, title: "Join the Community", description: "Connect with others making a difference (coming soon!)." },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center min-h-screen p-6 bg-gradient-to-br from-slate-50 to-stone-100 dark:from-slate-900 dark:to-stone-800"
    >
      <div className="max-w-2xl w-full text-center">
        <motion.h1 
          className="text-4xl md:text-5xl font-bold mb-6 text-primary dark:text-green-400"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          Welcome to Green Sprint!
        </motion.h1>
        <motion.p 
          className="text-lg text-slate-700 dark:text-slate-300 mb-10"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          Start your journey towards a more sustainable lifestyle. Every small step counts.
        </motion.p>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {features.map((feature, index) => (
            <motion.div 
              key={index}
              className="p-6 rounded-xl bg-white dark:bg-slate-800 shadow-lg hover:shadow-2xl transition-shadow duration-300"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 + index * 0.15, duration: 0.4 }}
            >
              <div className="flex justify-center mb-3">{feature.icon}</div>
              <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-1">{feature.title}</h2>
              <p className="text-sm text-slate-600 dark:text-slate-400">{feature.description}</p>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.5 }}
        >
          <Button
            onClick={handleCompleteOnboarding}
            size="lg"
            className="w-full md:w-auto bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-semibold py-3 px-8 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300"
          >
            Let's Get Started!
          </Button>
        </motion.div>
      </div>
       <footer className="absolute bottom-4 text-center w-full text-slate-500 dark:text-slate-400 text-sm">
        <p>&copy; {new Date().getFullYear()} Green Sprint. Your Eco Journey Companion.</p>
      </footer>
    </motion.div>
  );
};

export default OnboardingScreen;