import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Compass, Zap, BookOpen, Leaf, Droplets, Recycle, Library } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

const placeholderCategories = [
  { name: "Energy Saving", icon: <Zap className="w-10 h-10 text-yellow-400" />, description: "Discover tips to reduce your energy consumption at home and work. Small changes, big impact!", color: "yellow", imageKey: "lightbulb-idea" },
  { name: "Sustainable Swaps", icon: <Compass className="w-10 h-10 text-blue-400" />, description: "Find eco-friendly alternatives for everyday products. From kitchen to bathroom, swap for sustainability.", color: "blue", imageKey: "reusable-bottles" },
  { name: "Learn & Grow", icon: <BookOpen className="w-10 h-10 text-purple-400" />, description: "Expand your knowledge on environmental topics. Understand climate change, biodiversity, and more.", color: "purple", imageKey: "open-book-nature" },
  { name: "Go Green", icon: <Leaf className="w-10 h-10 text-green-500" />, description: "Explore plant-based living, gardening tips, and ways to connect with nature for a healthier planet.", color: "green", imageKey: "seedling-hands" },
  { name: "Water Wise", icon: <Droplets className="w-10 h-10 text-sky-500" />, description: "Tips for conserving precious water resources in your daily life, from the tap to the garden.", color: "sky", imageKey: "water-drop-leaf" },
  { name: "Reduce & Reuse", icon: <Recycle className="w-10 h-10 text-orange-500" />, description: "Learn to minimize waste, recycle effectively, and embrace a circular economy mindset.", color: "orange", imageKey: "recycling-bins" },
];

const imageGallery = [
  { srcKey: "forest-sunrise", alt: "Sunlight filtering through a misty forest path", description: "Forest Bathing" },
  { srcKey: "hands-planting-seedling", alt: "Close-up of hands carefully planting a small green seedling in rich dark soil", description: "Gardening" },
  { srcKey: "colorful-reusable-bags-market", alt: "A collection of vibrant reusable shopping bags filled with fresh fruits and vegetables at a market", description: "Sustainable Shopping" },
  { srcKey: "solar-panels-rooftop-sunset", alt: "Solar panels installed on a residential rooftop with a sunset in the background", description: "Renewable Energy" },
  { srcKey: "bicycle-leaning-green-wall", alt: "A modern bicycle leaning against a textured green wall in an urban setting", description: "Eco-Friendly Commute" },
  { srcKey: "community-garden-harvest", alt: "Diverse group of people harvesting vegetables in a lush community garden plot", description: "Local Initiatives" },
];

const greenLibraryArticles = [
  { id: 1, title: "The Ultimate Guide to Composting at Home", category: "Waste Reduction", date: "2025-05-20", summary: "Learn how to turn your kitchen scraps into nutrient-rich compost for your garden. Reduces landfill waste and improves soil health.", icon: <Recycle className="w-6 h-6 text-orange-500 mr-2" /> },
  { id: 2, title: "10 Easy Ways to Save Water Every Day", category: "Water Conservation", date: "2025-05-18", summary: "Simple habits that can make a big difference in your water consumption and bills. Every drop counts towards a sustainable future.", icon: <Droplets className="w-6 h-6 text-sky-500 mr-2" /> },
  { id: 3, title: "Understanding Your Carbon Footprint", category: "Climate Action", date: "2025-05-15", summary: "What is a carbon footprint and how can you reduce yours? A beginner's guide to making impactful changes for the climate.", icon: <Zap className="w-6 h-6 text-yellow-400 mr-2" /> },
];

const ExploreScreen = () => {
  const [selectedCategory, setSelectedCategory] = useState(null);

  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600 dark:from-blue-400 dark:to-purple-500">
          Explore Eco Ideas
        </h1>
        <p className="text-md text-slate-600 dark:text-slate-300 mt-2">
          Discover new ways to make a positive impact.
        </p>
      </header>
      
      <section>
        <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Categories</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {placeholderCategories.map((category, index) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
              className={`p-3 rounded-xl bg-white dark:bg-slate-800 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 glassmorphism cursor-pointer flex flex-col items-center text-center h-full border-b-4 border-${category.color}-500`}
              onClick={() => setSelectedCategory(category)}
            >
              {React.cloneElement(category.icon, { className: `w-8 h-8 text-${category.color}-500 mb-1.5`})}
              <h3 className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-100">{category.name}</h3>
            </motion.div>
          ))}
        </div>
      </section>

      <AnimatePresence>
        {selectedCategory && (
          <Dialog open={!!selectedCategory} onOpenChange={() => setSelectedCategory(null)}>
            <DialogContent className="sm:max-w-md glassmorphism">
              <DialogHeader className="items-center pt-4">
                {React.cloneElement(selectedCategory.icon, { className: `w-12 h-12 text-${selectedCategory.color}-500 mb-2`})}
                <DialogTitle className={`text-xl text-center text-${selectedCategory.color}-600 dark:text-${selectedCategory.color}-400`}>{selectedCategory.name}</DialogTitle>
              </DialogHeader>
              <DialogDescription className="text-center text-sm text-slate-600 dark:text-slate-300 px-4 py-1">
                {selectedCategory.description}
              </DialogDescription>
              <div className="mt-3 flex justify-center">
                <img  class="w-full max-w-[200px] h-auto rounded-lg shadow-md object-cover" alt={`${selectedCategory.name} illustrative image`} src="https://images.unsplash.com/photo-1684347417348-d261d03c60ef" />
              </div>
              <div className="mt-4 flex justify-end pb-4 px-4">
                <Button onClick={() => setSelectedCategory(null)} variant="outline" size="sm">Close</Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </AnimatePresence>

      <section>
        <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Inspiration Gallery</h2>
        <div className="grid grid-cols-2 gap-3">
          {imageGallery.map((image, index) => (
            <motion.div 
              key={image.srcKey}
              initial={{ opacity: 0, scale: 0.95 }} 
              animate={{ opacity: 1, scale: 1 }} 
              transition={{ delay: 0.1 + index * 0.05, duration: 0.4 }} 
              className="relative rounded-lg overflow-hidden shadow-md group aspect-square"
            >
              <img  class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" alt={image.alt} src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
              <div className="absolute inset-0 bg-black/40 flex items-end p-2"> 
                <p className="text-white text-xs font-semibold line-clamp-2">{image.description}</p> 
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200 flex items-center">
          <Library className="w-6 h-6 mr-2 text-green-600 dark:text-green-400" /> Green Library
        </h2>
        <div className="space-y-4">
          {greenLibraryArticles.map((article, index) => (
            <motion.div
              key={article.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 + index * 0.1, duration: 0.3 }}
            >
              <Card className="flex flex-col bg-white dark:bg-slate-800 shadow-lg hover:shadow-xl transition-shadow transform hover:-translate-y-0.5">
                <CardHeader className="pb-2 pt-4 px-4">
                  <div className="flex items-start mb-0.5">
                    {article.icon}
                    <CardTitle className="text-md leading-tight ml-1.5">{article.title}</CardTitle>
                  </div>
                  <CardDescription className="text-xs ml-8 -mt-1">{article.category} - {article.date}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow pt-0 pb-2 px-4">
                  <p className="text-sm text-slate-600 dark:text-slate-300 line-clamp-2">{article.summary}</p>
                </CardContent>
                <div className="px-4 pb-3 pt-0">
                  <Button variant="link" className="text-primary dark:text-green-400 p-0 text-sm">Read More &rarr;</Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      <div className="text-center mt-10 py-6 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/30 dark:to-emerald-900/30 rounded-lg">
        <Leaf size={32} className="mx-auto text-primary mb-2" />
        <p className="text-md text-slate-700 dark:text-slate-200">
          Stay tuned for more eco-inspiration!
        </p>
      </div>
    </div>
  );
};

export default ExploreScreen;