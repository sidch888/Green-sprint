import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import TaskCard from '@/components/TaskCard';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Leaf, MapPin, ArrowRight, PlusCircle, Filter, CheckCircle, Zap, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import AddTaskDialog from '@/components/sprint/AddTaskDialog';
import TaskFilters from '@/components/sprint/TaskFilters';
import LocalEventsSection from '@/components/sprint/LocalEventsSection';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';


const MOCK_TASKS_STORAGE_KEY = 'greenSprintTasks';
const USER_POINTS_STORAGE_KEY = 'greenSprintUserPoints';
const TASK_CATEGORIES = ["Swaps", "Advocacy", "Lifestyle", "Energy", "Waste Reduction", "Water Conservation", "Community"];
const TASK_POINTS_ON_COMPLETION = 20;

const AboutDialog = ({ isOpen, onOpenChange }) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md glassmorphism">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Leaf size={24} className="mr-2 text-primary" />
            About Green Sprint
          </DialogTitle>
          <DialogDescription className="pt-2 text-left">
            Green Sprint is a mobile-first application designed to empower individuals to take meaningful steps towards a more sustainable lifestyle. 
            Our mission is to make eco-friendly actions accessible, engaging, and rewarding.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-3 text-sm text-slate-700 dark:text-slate-300">
          <p>
            Crafted with care in <span className="font-semibold text-primary">Dublin, Ireland</span>, Green Sprint aims to foster a global community of environmentally conscious individuals. 
            We believe that small, consistent efforts can lead to significant positive change for our planet.
          </p>
          <p>
            Join us in tracking your eco-actions, discovering new challenges, and (soon!) connecting with a like-minded community.
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 pt-2">
            Version 1.0.0 | &copy; {new Date().getFullYear()} Green Sprint
          </p>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button" className="bg-primary hover:bg-primary/90 text-white">Got it!</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};


const SprintQueueScreen = () => {
  const [tasks, setTasks] = useState([]);
  const [userPoints, setUserPoints] = useState(0);
  const [isAddTaskDialogOpen, setIsAddTaskDialogOpen] = useState(false);
  const [isAboutDialogOpen, setIsAboutDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const navigate = useNavigate();
  const { toast } = useToast();

  const loadDataFromStorage = useCallback(() => {
    const storedTasks = JSON.parse(localStorage.getItem(MOCK_TASKS_STORAGE_KEY) || '[]');
    const storedPoints = JSON.parse(localStorage.getItem(USER_POINTS_STORAGE_KEY) || '0');
    setTasks(storedTasks);
    setUserPoints(storedPoints);
  }, []);

  useEffect(() => {
    loadDataFromStorage();
  }, [loadDataFromStorage]);

  const updateStoredTasks = (updatedTasks) => {
    localStorage.setItem(MOCK_TASKS_STORAGE_KEY, JSON.stringify(updatedTasks));
    setTasks(updatedTasks);
  };

  const updateStoredPoints = (points) => {
    localStorage.setItem(USER_POINTS_STORAGE_KEY, JSON.stringify(points));
    setUserPoints(points);
  };

  const handleToggleComplete = (taskId) => {
    let awardedPoints = 0;
    const taskToUpdate = tasks.find(task => task.id === taskId);

    const updatedTasks = tasks.map(task => {
      if (task.id === taskId) {
        if (!task.completed) {
          awardedPoints = task.points || TASK_POINTS_ON_COMPLETION;
        }
        return { ...task, completed: !task.completed };
      }
      return task;
    });

    updateStoredTasks(updatedTasks);

    if (awardedPoints > 0) {
      const newTotalPoints = userPoints + awardedPoints;
      updateStoredPoints(newTotalPoints);
      toast({
        title: `Task Completed! +${awardedPoints} Points!`,
        description: `"${taskToUpdate.title}" marked as complete. You now have ${newTotalPoints} points.`,
        className: "bg-yellow-400 border-yellow-400 text-slate-800"
      });
    } else {
      const taskNowIncomplete = updatedTasks.find(t => t.id === taskId);
      toast({
        title: `Task Marked Incomplete!`,
        description: `"${taskNowIncomplete.title}" status updated.`,
        variant: "destructive",
      });
    }
  };

  const handleAddTask = (newTaskData) => {
    const taskToAdd = {
      id: String(Date.now()),
      ...newTaskData,
      impact: parseFloat(newTaskData.impact),
      time: parseInt(newTaskData.time),
      points: parseInt(newTaskData.points),
      completed: false,
    };
    const updatedTasks = [taskToAdd, ...tasks];
    updateStoredTasks(updatedTasks);
    setIsAddTaskDialogOpen(false);
    toast({
      title: "Task Added!",
      description: `"${taskToAdd.title}" has been added to your sprint.`,
      className: "bg-green-500 border-green-500 text-white"
    });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const filteredTasks = tasks.filter(task => {
    const statusMatch = filterStatus === 'all' || (filterStatus === 'completed' && task.completed) || (filterStatus === 'active' && !task.completed);
    const categoryMatch = filterCategory === 'all' || task.category === filterCategory;
    return statusMatch && categoryMatch;
  });

  const activeTasks = filteredTasks.filter(task => !task.completed);
  const completedTasks = filteredTasks.filter(task => task.completed);

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div className="flex items-center mb-4 sm:mb-0">
          <Leaf size={32} className="mr-2 text-primary" />
          <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-green-500 to-emerald-700 dark:from-green-400 dark:to-emerald-600">
            Your Sprint
          </h1>
        </div>
        <div className="flex space-x-2">
          <TaskFilters
            filterStatus={filterStatus}
            setFilterStatus={setFilterStatus}
            filterCategory={filterCategory}
            setFilterCategory={setFilterCategory}
            taskCategories={TASK_CATEGORIES}
          />
          <Button size="sm" variant="outline" className="text-primary border-primary hover:bg-primary/10" onClick={() => setIsAboutDialogOpen(true)}>
            <Info size={16} className="mr-2" /> About
          </Button>
          <Button size="sm" className="bg-gradient-to-r from-primary to-emerald-600 hover:from-primary/90 hover:to-emerald-600/90 text-white" onClick={() => setIsAddTaskDialogOpen(true)}>
            <PlusCircle size={16} className="mr-2" /> Add Task
          </Button>
        </div>
      </header>

      <LocalEventsSection navigate={navigate} />
      
      <div className="mt-6 mb-6 text-center sm:text-left">
          <Button variant="link" className="text-primary dark:text-green-400 p-0 text-sm inline-flex items-center" onClick={() => navigate('/app/explore')}>
              Explore More Green Ideas & Events <ArrowRight size={14} className="ml-1" />
          </Button>
      </div>


      <AddTaskDialog
        isOpen={isAddTaskDialogOpen}
        onOpenChange={setIsAddTaskDialogOpen}
        onAddTask={handleAddTask}
        taskCategories={TASK_CATEGORIES}
        toast={toast}
      />
      <AboutDialog isOpen={isAboutDialogOpen} onOpenChange={setIsAboutDialogOpen} />


      {activeTasks.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Active Tasks ({activeTasks.length})</h2>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <AnimatePresence>
              {activeTasks.map(task => (
                <TaskCard key={task.id} task={task} onToggleComplete={handleToggleComplete} />
              ))}
            </AnimatePresence>
          </motion.div>
        </section>
      )}
      
      {activeTasks.length === 0 && filteredTasks.length > 0 && filterStatus !== 'completed' && (
         <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8 px-4 bg-green-50 dark:bg-green-900/20 rounded-lg"
        >
          <CheckCircle size={48} className="mx-auto text-primary mb-3" />
          <h2 className="text-2xl font-semibold text-primary mb-2">All active tasks completed!</h2>
          <p className="text-slate-600 dark:text-slate-300">Great job! Check your completed tasks or add new ones.</p>
        </motion.div>
      )}

      {filteredTasks.length === 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8 px-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg"
        >
          <Zap size={48} className="mx-auto text-yellow-500 mb-3" />
          <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-200 mb-2">No tasks match your filters!</h2>
          <p className="text-slate-600 dark:text-slate-300">Try adjusting your filters or add new tasks to your sprint.</p>
        </motion.div>
      )}
      

      {completedTasks.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Completed Tasks ({completedTasks.length})</h2>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <AnimatePresence>
              {completedTasks.map(task => (
                <TaskCard key={task.id} task={task} onToggleComplete={handleToggleComplete} />
              ))}
            </AnimatePresence>
          </motion.div>
        </section>
      )}
    </div>
  );
};

export default SprintQueueScreen;