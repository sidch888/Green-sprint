import React from 'react';
import { motion } from 'framer-motion';
import { UserCircle, Settings, Bell, Shield, LifeBuoy, ChevronRight, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

const ProfileScreen = ({ onLogout }) => {
  const { toast } = useToast();
  const navigate = useNavigate();

  const profileOptions = [
    { label: "Account Details", icon: <UserCircle className="w-5 h-5 mr-3 text-primary" />, action: () => console.log("Account Details") },
    { label: "Notifications", icon: <Bell className="w-5 h-5 mr-3 text-yellow-500" />, action: () => console.log("Notifications") },
    { label: "App Settings", icon: <Settings className="w-5 h-5 mr-3 text-blue-500" />, action: () => console.log("App Settings") },
    { label: "Privacy & Security", icon: <Shield className="w-5 h-5 mr-3 text-red-500" />, action: () => console.log("Privacy & Security") },
  ];

  const handleHelpSupport = () => {
    toast({
      title: "Contacting Support...",
      description: "You will be redirected to our support channel shortly. (This is a placeholder)",
      className: "bg-blue-500 border-blue-500 text-white"
    });
    console.log("Help & Support clicked");
  }

  const handleLogout = () => {
    onLogout(); // Call the onLogout prop passed from App.jsx
    toast({
      title: "Logging Out...",
      description: "You have been logged out successfully.",
      variant: "default"
    });
    navigate('/auth'); // Redirect to auth screen after logout
  }


  return (
    <div className="space-y-6 pb-8">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col items-center space-y-3 p-6 bg-gradient-to-br from-primary to-emerald-600 dark:from-primary/80 dark:to-emerald-600/80 rounded-xl shadow-xl text-center"
      >
        <div className="relative">
            <img  class="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-4 border-white shadow-md object-cover" alt="User profile picture" src="https://images.unsplash.com/photo-1679590988942-82d1575a83ae" />
            <Button size="icon" variant="secondary" className="absolute bottom-0 right-0 rounded-full w-8 h-8 sm:w-10 sm:h-10 shadow-md" onClick={() => console.log("Edit profile picture")}>
              <Settings size={18} />
            </Button>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white">Eco Warrior</h1>
        <p className="text-sm text-green-100">Joined: January 2025</p>
      </motion.div>

      <motion.div 
        className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.3 }}
      >
        <ul className="divide-y divide-slate-200 dark:divide-slate-700">
          {profileOptions.map((option, index) => (
            <motion.li
              key={option.label}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + index * 0.05, duration: 0.3 }}
              className="flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 cursor-pointer transition-colors first:rounded-t-lg last:rounded-b-lg"
              onClick={option.action}
              role="button"
              tabIndex={0}
              onKeyPress={(e) => e.key === 'Enter' && option.action()}
            >
              <div className="flex items-center">
                {option.icon}
                <span className="text-slate-700 dark:text-slate-200">{option.label}</span>
              </div>
              <ChevronRight size={20} className="text-slate-400 dark:text-slate-500" />
            </motion.li>
          ))}
        </ul>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25, duration: 0.3 }}
      >
        <Card className="bg-white dark:bg-slate-800 rounded-xl shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl flex items-center text-slate-700 dark:text-slate-100">
              <LifeBuoy className="w-6 h-6 mr-3 text-cyan-500" />
              Help & Support
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">
              Having trouble or have a question? Our support team is here to help you on your eco journey.
            </p>
            <Button 
              variant="outline" 
              className="w-full border-cyan-500 text-cyan-500 hover:bg-cyan-500/10 hover:text-cyan-600 dark:border-cyan-400 dark:text-cyan-400 dark:hover:bg-cyan-400/10 dark:hover:text-cyan-300"
              onClick={handleHelpSupport}
            >
              Contact Customer Care
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.3 }}
        className="px-2"
      >
        <Button 
          variant="destructive" 
          size="lg" 
          className="w-full"
          onClick={handleLogout}
        >
          <LogOut size={18} className="mr-2" /> Log Out
        </Button>
      </motion.div>

      <footer className="text-center text-slate-500 dark:text-slate-400 text-xs pt-4">
        <p>&copy; {new Date().getFullYear()} Green Sprint. All Rights Reserved.</p>
        <p>Version 1.0.0</p>
      </footer>
    </div>
  );
};

export default ProfileScreen;