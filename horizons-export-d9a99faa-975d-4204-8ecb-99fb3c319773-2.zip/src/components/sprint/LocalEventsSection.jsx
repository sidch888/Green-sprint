import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { MapPin, CalendarDays } from 'lucide-react';
import { motion } from 'framer-motion';

const localEventsPreviewData = [
    { 
      id: 1, 
      name: "Community Cleanup Day", 
      location: "Greenwood Park", 
      date: "2025-06-15", 
      description: "Join us for a park cleanup event. Gloves and bags provided!", 
      imageUrl: "https://images.unsplash.com/photo-1618477388954-7852f32655ec?q=80&w=800&auto=format&fit=crop" 
    },
    { 
      id: 2, 
      name: "Farmer's Market Opening", 
      location: "Town Square", 
      date: "2025-06-01", 
      description: "Support local farmers and get fresh, seasonal produce.", 
      imageUrl: "https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?q=80&w=800&auto=format&fit=crop"
    },
];

const LocalEventsSection = () => {
  return (
    <section>
      <div className="flex justify-between items-center mb-3">
          <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200 flex items-center">
              <MapPin className="w-6 h-6 mr-2 text-red-500 dark:text-red-400" /> Upcoming Local Events
          </h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {localEventsPreviewData.map((event, index) => (
              <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.3 }}
              >
                  <Card className="bg-white dark:bg-slate-800 shadow-lg hover:shadow-xl transition-shadow h-full group overflow-hidden">
                      <div className="h-40 overflow-hidden">
                          <img
                            src={event.imageUrl}
                            alt={`${event.name} event image`}
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                          />
                      </div>
                      <CardHeader className="pb-2 pt-3">
                          <CardTitle className="text-md leading-tight font-semibold">{event.name}</CardTitle>
                          <CardDescription className="text-xs flex items-center text-slate-500 dark:text-slate-400">
                              <CalendarDays size={12} className="mr-1" /> {event.date}
                          </CardDescription>
                      </CardHeader>
                      <CardContent className="pt-0 pb-3">
                          <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{event.description}</p>
                      </CardContent>
                  </Card>
              </motion.div>
          ))}
      </div>
    </section>
  );
};

export default LocalEventsSection;