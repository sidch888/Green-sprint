import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Circle, Zap, Clock, Award, UploadCloud } from 'lucide-react';
import { motion } from 'framer-motion';

const TaskCard = ({ task, onToggleComplete }) => {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.3 } },
  };

  const handleUploadClick = () => {
    // In a real app, this would open a file picker.
    // For now, it just toggles completion.
    onToggleComplete(task.id);
  };

  return (
    <motion.div variants={cardVariants}>
      <Card className={`mb-4 overflow-hidden flex flex-col h-full ${task.completed ? 'bg-green-50 dark:bg-green-900/30 border-green-300 dark:border-green-700' : 'bg-white dark:bg-slate-800 hover:shadow-green-200 dark:hover:shadow-green-700/30'}`}>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <CardTitle className={`text-lg ${task.completed ? 'line-through text-green-700 dark:text-green-500' : 'text-slate-800 dark:text-slate-100'}`}>
              {task.title}
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={() => onToggleComplete(task.id)} className="ml-2 -mt-2 -mr-2 flex-shrink-0">
              {task.completed ? <CheckCircle className="h-6 w-6 text-primary" /> : <Circle className="h-6 w-6 text-slate-400 dark:text-slate-500" />}
            </Button>
          </div>
          <CardDescription className={`${task.completed ? 'text-green-600 dark:text-green-400' : 'text-slate-500 dark:text-slate-400'}`}>
            Category: {task.category}
          </CardDescription>
        </CardHeader>
        <CardContent className="pb-4 pt-0 flex-grow">
          <div className="flex items-center text-sm text-slate-600 dark:text-slate-300 mb-1">
            <Zap size={16} className="mr-2 text-yellow-500" />
            Impact: {task.impact} units
          </div>
          <div className="flex items-center text-sm text-slate-600 dark:text-slate-300 mb-1">
            <Clock size={16} className="mr-2 text-blue-500" />
            Time: {task.time} min
          </div>
           <div className="flex items-center text-sm text-slate-600 dark:text-slate-300">
            <Award size={16} className="mr-2 text-amber-500" />
            Points: {task.points || 0}
          </div>
        </CardContent>
        {!task.completed && (
           <CardFooter className="p-0 mt-auto">
            <Button 
              onClick={handleUploadClick}
              className="w-full rounded-none rounded-b-xl bg-gradient-to-r from-blue-500 to-sky-600 hover:from-blue-500/90 hover:to-sky-600/90 text-white"
            >
              <UploadCloud size={16} className="mr-2" /> Upload a Photo
            </Button>
          </CardFooter>
        )}
      </Card>
    </motion.div>
  );
};

export default TaskCard;