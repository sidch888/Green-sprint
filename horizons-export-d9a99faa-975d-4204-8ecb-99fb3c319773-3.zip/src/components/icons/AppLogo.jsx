import React from 'react';
import { cn } from '@/lib/utils';

const AppLogo = ({ className, size = 'md' }) => {
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/d9a99faa-975d-4204-8ecb-99fb3c319773/07924ea3fc4f4095a1fa0d5b6bcd717e.png";
  
  let sizeClasses = "w-16 h-16"; // Default medium size

  if (size === 'sm') {
    sizeClasses = "w-8 h-8";
  } else if (size === 'lg') {
    sizeClasses = "w-24 h-24";
  } else if (size === 'xl') {
    sizeClasses = "w-32 h-32";
  }


  return (
    <img 
      src={logoUrl} 
      alt="Green Sprint App Logo" 
      className={cn(sizeClasses, "object-contain", className)} 
    />
  );
};

export default AppLogo;