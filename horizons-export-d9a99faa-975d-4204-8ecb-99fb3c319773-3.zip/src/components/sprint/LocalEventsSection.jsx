import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { MapPin, CalendarDays } from 'lucide-react';
import { motion } from 'framer-motion';

const localEventsPreviewData = [
    { 
      id: 1, 
      name: "Community Cleanup Day", 
      location: "Greenwood Park", 
      date: "2025-06-15", 
      description: "Join us for a park cleanup event. Gloves and bags provided!", 
      imageUrl: "https://d1pb80m7gb5pne.cloudfront.net/wp-content/uploads/How-to-Organize-a-Community-Clean-Up-Day-Step-by-Step-Guide.jpg"
    },
    { 
      id: 2, 
      name: "Farmer's Market Opening", 
      location: "Town Square", 
      date: "2025-06-01", 
      description: "Support local farmers and get fresh, seasonal produce.", 
      imageUrl: "https://i0.wp.com/ithacavoice.s3.amazonaws.com/ithacavoice/wp-content/uploads/2019/04/ithaca-farmers-market-opening-day_mroczek-jacob_20190406_14.jpg?fit=1920%2C1280&quality=89&ssl=1"
    },
];

const LocalEventsSection = () => {
  return (
    <section>
      <div className="flex justify-between items-center mb-3">
          <h2 className="text-xl font-semibold text-foreground flex items-center">
              <MapPin className="w-6 h-6 mr-2 text-brand-primary-button" /> Upcoming Local Events
          </h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {localEventsPreviewData.map((event, index) => (
              <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.3 }}
              >
                  <Card className="card-themed h-full group overflow-hidden">
                      <div className="h-40 overflow-hidden">
                          <img 
                            src={event.imageUrl}
                            alt={`${event.name} event image`}
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                           />
                      </div>
                      <CardHeader className="pb-2 pt-3">
                          <CardTitle className="text-md leading-tight font-semibold text-foreground">{event.name}</CardTitle>
                          <CardDescription className="text-xs flex items-center text-muted-foreground">
                              <CalendarDays size={12} className="mr-1" /> {event.date}
                          </CardDescription>
                      </CardHeader>
                      <CardContent className="pt-0 pb-3">
                          <p className="text-xs text-muted-foreground line-clamp-2">{event.description}</p>
                      </CardContent>
                  </Card>
              </motion.div>
          ))}
      </div>
    </section>
  );
};

export default LocalEventsSection;