import React from 'react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuCheckboxItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Filter } from 'lucide-react';

const TaskFilters = ({ filterStatus, setFilterStatus, filterCategory, setFilterCategory, taskCategories }) => {
  const isFilterActive = filterStatus !== 'all' || filterCategory !== 'all';

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="bg-secondary hover:bg-secondary/80">
          <Filter size={16} className="mr-2" /> Filter ({isFilterActive ? 'Active' : 'None'})
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56">
        <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuCheckboxItem checked={filterStatus === 'all'} onCheckedChange={() => setFilterStatus('all')}>All</DropdownMenuCheckboxItem>
        <DropdownMenuCheckboxItem checked={filterStatus === 'active'} onCheckedChange={() => setFilterStatus('active')}>Active</DropdownMenuCheckboxItem>
        <DropdownMenuCheckboxItem checked={filterStatus === 'completed'} onCheckedChange={() => setFilterStatus('completed')}>Completed</DropdownMenuCheckboxItem>
        
        <DropdownMenuLabel>Filter by Category</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuCheckboxItem checked={filterCategory === 'all'} onCheckedChange={() => setFilterCategory('all')}>All Categories</DropdownMenuCheckboxItem>
        {taskCategories.map(cat => (
          <DropdownMenuCheckboxItem key={cat} checked={filterCategory === cat} onCheckedChange={() => setFilterCategory(cat)}>{cat}</DropdownMenuCheckboxItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default TaskFilters;