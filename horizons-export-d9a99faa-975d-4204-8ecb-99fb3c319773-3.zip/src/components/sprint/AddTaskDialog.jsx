import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';

const AddTaskDialog = ({ isOpen, onOpenChange, onAddTask, taskCategories, toast }) => {
  const [newTask, setNewTask] = useState({ title: '', category: '', impact: '', time: '', points: '' });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTask(prev => ({ ...prev, [name]: value }));
  };

  const handleCategoryChange = (value) => {
    setNewTask(prev => ({ ...prev, category: value }));
  };

  const handleSubmit = () => {
    if (!newTask.title || !newTask.category || !newTask.impact || !newTask.time || !newTask.points) {
      toast({
        title: "Missing Information",
        description: "Please fill out all fields to add a task.",
        variant: "destructive",
      });
      return;
    }
    onAddTask(newTask);
    setNewTask({ title: '', category: '', impact: '', time: '', points: '' }); 
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] glassmorphism">
        <DialogHeader>
          <DialogTitle>Add New Eco Task</DialogTitle>
          <DialogDescription>
            Describe the task you want to add. Every action counts! Earn points for completion.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="title" className="text-right">Title</Label>
            <Input id="title" name="title" value={newTask.title} onChange={handleInputChange} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="category" className="text-right">Category</Label>
            <Select onValueChange={handleCategoryChange} value={newTask.category}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {taskCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="impact" className="text-right">Impact</Label>
            <Input id="impact" name="impact" type="number" placeholder="e.g. 0.05" value={newTask.impact} onChange={handleInputChange} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="time" className="text-right">Time (min)</Label>
            <Input id="time" name="time" type="number" placeholder="e.g. 10" value={newTask.time} onChange={handleInputChange} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="points" className="text-right">Points</Label>
            <Input id="points" name="points" type="number" placeholder="e.g. 20" value={newTask.points} onChange={handleInputChange} className="col-span-3" />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button" variant="secondary">Cancel</Button>
          </DialogClose>
          <Button type="button" onClick={handleSubmit}>Add Task</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddTaskDialog;