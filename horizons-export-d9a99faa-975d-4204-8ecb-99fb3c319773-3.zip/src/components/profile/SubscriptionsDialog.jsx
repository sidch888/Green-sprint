import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription as DialogDesc, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Gift, ChevronRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const SubscriptionsDialog = ({ isOpen, onOpenChange }) => {
  const subscriptions = [
    { name: "Seedling Starter", price: "€4.99/month", features: ["Basic Tracking", "Community Access", "Standard Challenges"] },
    { name: "Eco Enthusiast", price: "€9.99/month", features: ["Advanced Tracking", "Exclusive Content", "Early Access to Challenges", "Priority Support"] },
    { name: "Planet Protector", price: "€19.99/month", features: ["All Eco Enthusiast features", "Personalized Coaching (beta)", "Direct Impact Projects Contribution"] },
  ];
  const { toast } = useToast();

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg dialog-content-themed">
        <DialogHeader>
          <DialogTitle className="flex items-center text-brand-text"><Gift size={24} className="mr-2 text-brand-primary-button" /> Our Subscriptions</DialogTitle>
          <DialogDesc className="text-brand-text opacity-80">Upgrade your Green Sprint experience and support our mission!</DialogDesc>
        </DialogHeader>
        <div className="py-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          {subscriptions.map(sub => (
            <Card key={sub.name} className="flex flex-col card-themed">
              <CardHeader>
                <CardTitle className="text-lg text-brand-primary-button">{sub.name}</CardTitle>
                <CardDescription className="text-2xl font-bold text-brand-text">{sub.price}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <ul className="space-y-1 text-xs text-brand-text opacity-90">
                  {sub.features.map(feature => <li key={feature} className="flex items-center"><ChevronRight size={12} className="mr-1 text-green-500" /> {feature}</li>)}
                </ul>
              </CardContent>
              <DialogFooter className="p-4 mt-auto">
                <Button className="w-full button-primary-themed" onClick={() => {
                  toast({title: `Subscribed to ${sub.name}!`, description: `Thank you for your support! (Simulated)`});
                  onOpenChange(false); // Close dialog on choosing plan
                }}>Choose Plan</Button>
              </DialogFooter>
            </Card>
          ))}
        </div>
         <DialogFooter className="mt-2">
          <DialogClose asChild>
            <Button type="button" variant="outline" className="text-brand-text border-brand-text/50 hover:bg-brand-text/10">Close</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SubscriptionsDialog;