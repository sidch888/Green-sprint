import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';

const ProfileMenuItem = ({ option, index }) => (
  <motion.li
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay: 0.2 + index * 0.05, duration: 0.3 }}
    className="flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 cursor-pointer transition-colors first:rounded-t-lg last:rounded-b-lg"
    onClick={option.action}
    role="button"
    tabIndex={0}
    onKeyPress={(e) => e.key === 'Enter' && option.action()}
  >
    <div className="flex items-center">
      {React.cloneElement(option.icon, { className: `w-5 h-5 mr-3 ${option.colorClass || 'text-brand-primary-button'}` })}
      <span className="text-brand-text">{option.label}</span>
    </div>
    <ChevronRight size={20} className="text-slate-400 dark:text-slate-500" />
  </motion.li>
);


const ProfileMenuList = ({ options }) => {
  return (
    <motion.div 
      className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-2 card-themed"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1, duration: 0.3 }}
    >
      <ul className="divide-y divide-slate-200 dark:divide-slate-700">
        {options.map((option, index) => (
          <ProfileMenuItem key={option.label} option={option} index={index} />
        ))}
      </ul>
    </motion.div>
  );
};

export default ProfileMenuList;