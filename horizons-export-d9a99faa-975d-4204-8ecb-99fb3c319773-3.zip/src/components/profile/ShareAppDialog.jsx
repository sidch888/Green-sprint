import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription as DialogDesc, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Share2, Instagram, Facebook, MessageCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ShareAppDialog = ({ isOpen, onOpenChange }) => {
  const { toast } = useToast();
  const websiteUrl = "https://greensprint.app"; 
  const sharePlatforms = [
    { name: "Instagram", icon: <Instagram className="w-5 h-5 mr-2" />, action: () => toast({ title: "Shared on Instagram!", description: "Thanks for spreading the word! (Simulated)"}) },
    { name: "Facebook", icon: <Facebook className="w-5 h-5 mr-2" />, action: () => toast({ title: "Shared on Facebook!", description: "Thanks for spreading the word! (Simulated)"}) },
    { name: "Messages", icon: <MessageCircle className="w-5 h-5 mr-2" />, action: () => toast({ title: "Shared via Messages!", description: "Thanks for spreading the word! (Simulated)"}) },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md dialog-content-themed">
        <DialogHeader>
          <DialogTitle className="flex items-center text-brand-text"><Share2 size={24} className="mr-2 text-brand-primary-button" /> Share Green Sprint</DialogTitle>
          <DialogDesc className="text-brand-text opacity-80">Help us grow our community of eco-warriors!</DialogDesc>
        </DialogHeader>
        <div className="py-4 space-y-4 text-center">
            <div className="flex justify-center">
              <img  alt="QR code to share app" className="w-32 h-32 p-1 border rounded-md bg-white" src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://greensprint.app" />
            </div>
            <p className="text-xs text-brand-text opacity-70">Scan to visit: {websiteUrl}</p>
          <div className="space-y-2 pt-2">
            {sharePlatforms.map(platform => (
              <Button key={platform.name} variant="outline" className="w-full justify-start text-brand-text border-brand-text/50 hover:bg-brand-text/10" onClick={platform.action}>
                {platform.icon} {platform.name}
              </Button>
            ))}
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button type="button" variant="ghost" className="text-brand-text hover:bg-brand-text/10">Close</Button></DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ShareAppDialog;