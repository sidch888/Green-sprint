import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Settings } from 'lucide-react';
import AppLogo from '@/components/icons/AppLogo';

const ProfileHeader = ({ onEditProfilePic }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col items-center space-y-3 p-6 bg-gradient-to-br from-brand-primary-button to-emerald-600 dark:from-brand-primary-button/80 dark:to-emerald-600/80 rounded-xl shadow-xl text-center"
    >
      <div className="relative">
        <img  className="w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 border-white shadow-md object-cover" alt="User profile picture" src="https://images.unsplash.com/photo-1699811250955-143c4234902c" />
        <Button size="icon" variant="secondary" className="absolute bottom-0 right-0 rounded-full w-8 h-8 sm:w-9 sm:h-9 shadow-md bg-white/80 hover:bg-white" onClick={onEditProfilePic}>
          <Settings size={16} className="text-brand-text" />
        </Button>
      </div>
      <h1 className="text-2xl sm:text-3xl font-bold text-white">Eco Warrior</h1>
      <p className="text-sm text-green-100">Joined: January 2025</p>
    </motion.div>
  );
};

export default ProfileHeader;