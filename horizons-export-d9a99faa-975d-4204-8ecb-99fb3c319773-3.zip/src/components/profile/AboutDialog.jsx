import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription as DialogDesc, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import AppLogo from '@/components/icons/AppLogo';

const AboutDialog = ({ isOpen, onOpenChange }) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md dialog-content-themed">
        <DialogHeader>
          <DialogTitle className="flex items-center text-brand-text">
            <AppLogo size="sm" className="mr-2" />
            About Green Sprint
          </DialogTitle>
          <DialogDesc className="pt-2 text-left text-brand-text opacity-80">
            Green Sprint is a mobile-first application designed to empower individuals to take meaningful steps towards a more sustainable lifestyle. 
            Our mission is to make eco-friendly actions accessible, engaging, and rewarding.
          </DialogDesc>
        </DialogHeader>
        <div className="py-4 space-y-3 text-sm text-brand-text opacity-90">
          <p>
            Crafted with care in <span className="font-semibold text-brand-primary-button">Dublin, Ireland</span>, Green Sprint aims to foster a global community of environmentally conscious individuals. 
            We believe that small, consistent efforts can lead to significant positive change for our planet.
          </p>
          <p>
            Join us in tracking your eco-actions, discovering new challenges, and connecting with a like-minded community.
          </p>
          <p className="text-xs text-brand-text opacity-70 pt-2">
            Version 1.0.0 | &copy; {new Date().getFullYear()} Green Sprint
          </p>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button" className="button-primary-themed">Got it!</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AboutDialog;