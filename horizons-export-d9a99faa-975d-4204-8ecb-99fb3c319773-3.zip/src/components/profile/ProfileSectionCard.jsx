import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const ProfileSectionCard = ({ icon, title, description, buttonText, onButtonClick, delay = 0.25, buttonVariant = "outline", buttonColorClass = "border-brand-primary-button text-brand-primary-button hover:bg-brand-primary-button/10 hover:text-brand-primary-button/80" }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.3 }}
    >
      <Card className="card-themed rounded-xl shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl flex items-center text-brand-text">
            {icon}
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-brand-text opacity-80 mb-4">
            {description}
          </p>
          <Button 
            variant={buttonVariant}
            className={`w-full ${buttonColorClass}`}
            onClick={onButtonClick}
          >
            {buttonText}
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProfileSectionCard;