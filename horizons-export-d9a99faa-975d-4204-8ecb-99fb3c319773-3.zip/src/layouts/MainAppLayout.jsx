import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import BottomNavBar from '@/components/BottomNavBar';
import { motion, AnimatePresence } from 'framer-motion';

const MainAppLayout = () => {
  const location = useLocation();

  return (
    <div className="flex justify-center items-center min-h-screen bg-white p-0 sm:p-4 md:p-8">
      <div 
        className="w-full max-w-sm flex flex-col min-h-screen sm:min-h-[90vh] sm:max-h-[90vh] bg-brand-background text-brand-text shadow-2xl sm:rounded-3xl overflow-hidden"
      >
        <main className="flex-grow px-4 py-6 pb-24 md:pb-6 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="w-full"
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
        <BottomNavBar />
      </div>
    </div>
  );
};

export default MainAppLayout;