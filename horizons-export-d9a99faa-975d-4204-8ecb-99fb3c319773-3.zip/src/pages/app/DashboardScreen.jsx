import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BarChartBig, TrendingUp, Target, Award, Users, Crown, Gift, Share2, Instagram, Facebook, MessageCircle } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';


const USER_POINTS_STORAGE_KEY = 'greenSprintUserPoints';
const MOCK_TASKS_STORAGE_KEY = 'greenSprintTasks';

const ShareScoreDialog = ({ isOpen, onOpenChange, score }) => {
  const { toast } = useToast();
  const sharePlatforms = [
    { name: "Instagram", icon: <Instagram className="w-5 h-5 mr-2" />, action: () => toast({ title: "Shared on Instagram!", description: `Your score of ${score} is now on Instagram! (Simulated)` }) },
    { name: "Facebook", icon: <Facebook className="w-5 h-5 mr-2" />, action: () => toast({ title: "Shared on Facebook!", description: `Your score of ${score} is now on Facebook! (Simulated)` }) },
    { name: "Snapchat", icon: <MessageCircle className="w-5 h-5 mr-2" />, action: () => toast({ title: "Shared on Snapchat!", description: `Your score of ${score} is now on Snapchat! (Simulated)` }) },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md glassmorphism">
        <DialogHeader>
          <DialogTitle className="flex items-center"><Share2 size={24} className="mr-2 text-primary" /> Share Your Score!</DialogTitle>
          <DialogDescription>
            Let your friends know about your awesome eco-progress! You've earned {score} points!
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-3">
          {sharePlatforms.map(platform => (
            <Button key={platform.name} variant="outline" className="w-full justify-start" onClick={platform.action}>
              {platform.icon} {platform.name}
            </Button>
          ))}
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button" variant="ghost">Cancel</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};


const DashboardScreen = () => {
  const [userPoints, setUserPoints] = useState(0);
  const [tasksCompleted, setTasksCompleted] = useState(0);
  const [isShareScoreDialogOpen, setIsShareScoreDialogOpen] = useState(false);
  
  useEffect(() => {
    const storedPoints = JSON.parse(localStorage.getItem(USER_POINTS_STORAGE_KEY) || '0');
    setUserPoints(storedPoints);

    const storedTasks = JSON.parse(localStorage.getItem(MOCK_TASKS_STORAGE_KEY) || '[]');
    const completedCount = storedTasks.filter(task => task.completed).length;
    setTasksCompleted(completedCount);
  }, []);


  const stats = [
    { label: "Tasks Done", value: tasksCompleted, icon: <BarChartBig className="w-10 h-10 text-primary" />, color: "green" },
    { label: "Impact Score", value: (userPoints * 0.013).toFixed(2), icon: <TrendingUp className="w-10 h-10 text-blue-500" />, color: "blue" },
    { label: "Total Points", value: userPoints, icon: <Gift className="w-10 h-10 text-yellow-500" />, color: "yellow" },
  ];

  const scoreboardData = [
    { rank: 1, name: "Alex Green", score: 1500, avatarImageSrc: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tJTIwcGVyc29ufGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=100&q=60", icon: <Crown className="w-5 h-5 text-yellow-400" /> },
    { rank: 2, name: "Bella Bloom", score: 1350, avatarImageSrc: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8cmFuZG9tJTIwcGVyc29ufGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=100&q=60" },
    { rank: 3, name: "Carlos River", score: 1200, avatarImageSrc: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8cmFuZG9tJTIwcGVyc29ufGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=100&q=60" },
    { rank: 4, name: "You", score: userPoints, avatarImageSrc: "https://images.unsplash.com/photo-1690721606848-ac5bdcde45ea", isCurrentUser: true },
    { rank: 5, name: "Diana Sky", score: 900, avatarImageSrc: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8cmFuZG9tJTIwcGVyc29ufGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=100&q=60" },
  ].sort((a, b) => b.score - a.score).map((user, index) => ({ ...user, rank: index + 1 }));


  const progressPercentage = Math.min((userPoints / 2000) * 100, 100);

  return (
    <div className="space-y-8">
      <ShareScoreDialog isOpen={isShareScoreDialogOpen} onOpenChange={setIsShareScoreDialogOpen} score={userPoints} />
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-yellow-500 to-orange-600 dark:from-yellow-400 dark:to-orange-500">
        Your Dashboard
      </h1>
      
      <section>
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200">Quick Stats</h2>
        <div className="grid grid-cols-3 gap-3">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.3 }}
              className={`p-3 rounded-xl bg-white dark:bg-slate-800 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 glassmorphism cursor-pointer flex flex-col items-center text-center aspect-square justify-center border-b-4 border-${stat.color}-500`}
            >
              {React.cloneElement(stat.icon, { className: `w-8 h-8 text-${stat.color}-500 mb-1.5`})}
              <p className={`text-2xl font-bold text-${stat.color}-600 dark:text-${stat.color}-400`}>{stat.value}</p>
              <h3 className="text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200 mt-1">{stat.label}</h3>
            </motion.div>
          ))}
        </div>
      </section>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.3 }}
        className="p-6 rounded-xl bg-white dark:bg-slate-800 shadow-lg glassmorphism"
      >
        <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-3">Overall Progress</h2>
        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-6">
          <motion.div 
            className="bg-gradient-to-r from-primary to-emerald-500 h-6 rounded-full flex items-center justify-center text-xs font-medium text-white"
            initial={{ width: '0%'}}
            animate={{ width: `${progressPercentage}%`}}
            transition={{ delay: 0.4, duration: 0.8, type: "spring" }}
          >
            {progressPercentage.toFixed(0)}%
          </motion.div>
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">Your journey to 2000 points!</p>
      </motion.div>

      <section>
        <h2 className="text-2xl font-semibold mb-4 text-slate-700 dark:text-slate-200 flex items-center">
          <Award className="w-7 h-7 mr-2 text-amber-500" /> Scoreboard
        </h2>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.3 }}
          className="bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden glassmorphism"
        >
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {scoreboardData.map((user, index) => (
              <motion.li
                key={user.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.05, duration: 0.3 }}
                className={`flex items-center justify-between p-3 sm:p-4 transition-colors ${user.isCurrentUser ? 'bg-green-100 dark:bg-green-900/50' : 'hover:bg-slate-50 dark:hover:bg-slate-700/50'}`}
              >
                <div className="flex items-center">
                  <span className={`text-md sm:text-lg font-semibold w-6 sm:w-8 text-center ${user.rank <= 3 ? 'text-amber-500' : 'text-slate-500 dark:text-slate-400'}`}>
                    {user.rank}
                  </span>
                  <Avatar className="w-8 h-8 sm:w-10 sm:h-10 ml-2 sm:ml-3 mr-2 sm:mr-3 border-2 border-slate-300 dark:border-slate-600">
                    <AvatarImage src={user.avatarImageSrc} alt={user.name} />
                    <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <span className={`font-medium text-sm sm:text-base ${user.isCurrentUser ? 'text-primary dark:text-green-400' : 'text-slate-700 dark:text-slate-200'}`}>{user.name}</span>
                  {user.icon && <span className="ml-1">{user.icon}</span>}
                </div>
                <span className={`font-semibold text-md sm:text-lg ${user.isCurrentUser ? 'text-primary dark:text-green-400' : 'text-slate-600 dark:text-slate-300'}`}>{user.score} pts</span>
              </motion.li>
            ))}
          </ul>
        </motion.div>
        <div className="mt-4 text-center">
          <Button 
            onClick={() => setIsShareScoreDialogOpen(true)} 
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
          >
            <Share2 size={18} className="mr-2" /> Share Your Score
          </Button>
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-3 text-center">
          Compete and climb the ranks! Scores update as you complete tasks.
        </p>
      </section>
      
      <div className="text-center mt-10">
        <Users size={48} className="mx-auto text-primary mb-3" />
        <p className="text-slate-600 dark:text-slate-300">Join challenges, earn points, and see your name on top!</p>
      </div>
    </div>
  );
};

export default DashboardScreen;