import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { UserCircle, Settings, Bell, Shield, LifeBuoy, Info, Gift, Share2, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

import ProfileHeader from '@/components/profile/ProfileHeader';
import ProfileMenuList from '@/components/profile/ProfileMenuList';
import ProfileSectionCard from '@/components/profile/ProfileSectionCard';
import AboutDialog from '@/components/profile/AboutDialog';
import SubscriptionsDialog from '@/components/profile/SubscriptionsDialog';
import ShareAppDialog from '@/components/profile/ShareAppDialog';


const ProfileScreen = ({ onLogout }) => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isAboutDialogOpen, setIsAboutDialogOpen] = useState(false);
  const [isSubscriptionsDialogOpen, setIsSubscriptionsDialogOpen] = useState(false);
  const [isShareAppDialogOpen, setIsShareAppDialogOpen] = useState(false);

  const profileOptions = [
    { label: "Account Details", icon: <UserCircle />, colorClass: "text-blue-500", action: () => console.log("Account Details") },
    { label: "Subscriptions", icon: <Gift />, colorClass: "text-purple-500", action: () => setIsSubscriptionsDialogOpen(true) },
    { label: "Notifications", icon: <Bell />, colorClass: "text-yellow-500", action: () => console.log("Notifications") },
    { label: "App Settings", icon: <Settings />, colorClass: "text-slate-500", action: () => console.log("App Settings") },
    { label: "Privacy & Security", icon: <Shield />, colorClass: "text-red-500", action: () => console.log("Privacy & Security") },
    { label: "About Green Sprint", icon: <Info />, colorClass: "text-teal-500", action: () => setIsAboutDialogOpen(true) },
  ];

  const handleHelpSupport = () => {
    toast({
      title: "Contacting Support...",
      description: "You will be redirected to our support channel shortly. (This is a placeholder)",
      className: "bg-blue-500 border-blue-500 text-white"
    });
  };

  const handleLogoutAction = () => {
    onLogout();
    toast({
      title: "Logging Out...",
      description: "You have been logged out successfully.",
    });
    navigate('/auth');
  };

  const handleEditProfilePic = () => {
    toast({ title: "Edit Profile Picture", description: "Functionality to change profile picture coming soon!"});
  }

  return (
    <div className="space-y-6 pb-8 text-brand-text">
      <AboutDialog isOpen={isAboutDialogOpen} onOpenChange={setIsAboutDialogOpen} />
      <SubscriptionsDialog isOpen={isSubscriptionsDialogOpen} onOpenChange={setIsSubscriptionsDialogOpen} />
      <ShareAppDialog isOpen={isShareAppDialogOpen} onOpenChange={setIsShareAppDialogOpen} />

      <ProfileHeader onEditProfilePic={handleEditProfilePic} />
      <ProfileMenuList options={profileOptions} />
      
      <ProfileSectionCard 
        icon={<LifeBuoy className="w-6 h-6 mr-3 text-cyan-500" />}
        title="Help & Support"
        description="Having trouble or have a question? Our support team is here to help you on your eco journey."
        buttonText="Contact Customer Care"
        onButtonClick={handleHelpSupport}
        delay={0.25}
        buttonColorClass="border-cyan-500 text-cyan-500 hover:bg-cyan-500/10 hover:text-cyan-600 dark:border-cyan-400 dark:text-cyan-400 dark:hover:bg-cyan-400/10 dark:hover:text-cyan-300"
      />

      <ProfileSectionCard 
        icon={<Share2 className="w-6 h-6 mr-3 text-purple-500" />}
        title="Share App"
        description="Love Green Sprint? Share it with your friends and family!"
        buttonText="Share Green Sprint"
        onButtonClick={() => setIsShareAppDialogOpen(true)}
        delay={0.3}
        buttonColorClass="border-purple-500 text-purple-500 hover:bg-purple-500/10 hover:text-purple-600 dark:border-purple-400 dark:text-purple-400 dark:hover:bg-purple-400/10 dark:hover:text-purple-300"
      />
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35, duration: 0.3 }}
        className="px-2"
      >
        <Button 
          variant="destructive" 
          size="lg" 
          className="w-full bg-red-500 hover:bg-red-600 text-white"
          onClick={handleLogoutAction}
        >
          <LogOut size={18} className="mr-2" /> Log Out
        </Button>
      </motion.div>

      <footer className="text-center text-brand-text opacity-70 text-xs pt-4">
        <p>&copy; {new Date().getFullYear()} Green Sprint. All Rights Reserved.</p>
        <p>Version 1.0.0</p>
      </footer>
    </div>
  );
};

export default ProfileScreen;