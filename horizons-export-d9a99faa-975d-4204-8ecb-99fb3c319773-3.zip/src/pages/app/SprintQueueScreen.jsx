import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import TaskCard from '@/components/TaskCard';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ArrowRight, PlusCircle, CheckCircle, Zap } from 'lucide-react';
import AppLogo from '@/components/icons/AppLogo';
import { motion, AnimatePresence } from 'framer-motion';
import AddTaskDialog from '@/components/sprint/AddTaskDialog';
import TaskFilters from '@/components/sprint/TaskFilters';
import LocalEventsSection from '@/components/sprint/LocalEventsSection';

const MOCK_TASKS_STORAGE_KEY = 'greenSprintTasks';
const USER_POINTS_STORAGE_KEY = 'greenSprintUserPoints';
const TASK_CATEGORIES = ["Swaps", "Advocacy", "Lifestyle", "Energy", "Waste Reduction", "Water Conservation", "Community"];
const TASK_POINTS_ON_COMPLETION = 20;


const SprintQueueScreen = () => {
  const [tasks, setTasks] = useState([]);
  const [userPoints, setUserPoints] = useState(0);
  const [isAddTaskDialogOpen, setIsAddTaskDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const navigate = useNavigate();
  const { toast } = useToast();

  const loadDataFromStorage = useCallback(() => {
    const storedTasks = JSON.parse(localStorage.getItem(MOCK_TASKS_STORAGE_KEY) || '[]');
    const storedPoints = JSON.parse(localStorage.getItem(USER_POINTS_STORAGE_KEY) || '0');
    setTasks(storedTasks);
    setUserPoints(storedPoints);
  }, []);

  useEffect(() => {
    loadDataFromStorage();
  }, [loadDataFromStorage]);

  const updateStoredTasks = (updatedTasks) => {
    localStorage.setItem(MOCK_TASKS_STORAGE_KEY, JSON.stringify(updatedTasks));
    setTasks(updatedTasks);
  };

  const updateStoredPoints = (points) => {
    localStorage.setItem(USER_POINTS_STORAGE_KEY, JSON.stringify(points));
    setUserPoints(points);
  };

  const handleToggleComplete = (taskId) => {
    let awardedPoints = 0;
    const taskToUpdate = tasks.find(task => task.id === taskId);

    const updatedTasks = tasks.map(task => {
      if (task.id === taskId) {
        if (!task.completed) {
          awardedPoints = task.points || TASK_POINTS_ON_COMPLETION;
        }
        return { ...task, completed: !task.completed };
      }
      return task;
    });

    updateStoredTasks(updatedTasks);

    if (awardedPoints > 0) {
      const newTotalPoints = userPoints + awardedPoints;
      updateStoredPoints(newTotalPoints);
      toast({
        title: `Task Verified! +${awardedPoints} Points!`,
        description: `"${taskToUpdate.title}" marked as complete. You now have ${newTotalPoints} points.`,
        className: "bg-yellow-400 border-yellow-400 text-slate-800" 
      });
    } else {
      const taskNowIncomplete = updatedTasks.find(t => t.id === taskId);
      toast({
        title: `Task Marked Incomplete!`,
        description: `"${taskNowIncomplete.title}" status updated.`,
        variant: "destructive",
      });
    }
  };

  const handleAddTask = (newTaskData) => {
    const taskToAdd = {
      id: String(Date.now()),
      ...newTaskData,
      impact: parseFloat(newTaskData.impact),
      time: parseInt(newTaskData.time),
      points: parseInt(newTaskData.points),
      completed: false,
    };
    const updatedTasks = [taskToAdd, ...tasks];
    updateStoredTasks(updatedTasks);
    setIsAddTaskDialogOpen(false);
    toast({
      title: "Task Added!",
      description: `"${taskToAdd.title}" has been added to your sprint.`,
      className: "bg-brand-primary-button border-brand-primary-button text-white"
    });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const filteredTasks = tasks.filter(task => {
    const statusMatch = filterStatus === 'all' || (filterStatus === 'completed' && task.completed) || (filterStatus === 'active' && !task.completed);
    const categoryMatch = filterCategory === 'all' || task.category === filterCategory;
    return statusMatch && categoryMatch;
  });

  const activeTasks = filteredTasks.filter(task => !task.completed);
  const completedTasks = filteredTasks.filter(task => task.completed);

  return (
    <div className="space-y-6 text-brand-text">
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div className="flex items-center mb-4 sm:mb-0">
          <AppLogo size="sm" className="mr-2" />
          <h1 className="text-2xl font-bold text-brand-text">
            Your Sprint
          </h1>
        </div>
        <div className="flex space-x-2">
          <TaskFilters
            filterStatus={filterStatus}
            setFilterStatus={setFilterStatus}
            filterCategory={filterCategory}
            setFilterCategory={setFilterCategory}
            taskCategories={TASK_CATEGORIES}
          />
          <Button size="sm" className="button-primary-themed" onClick={() => setIsAddTaskDialogOpen(true)}>
            <PlusCircle size={16} className="mr-2" /> Add Task
          </Button>
        </div>
      </header>

      <LocalEventsSection navigate={navigate} />
      
      <div className="mt-6 mb-6 text-center sm:text-left">
          <Button variant="link" className="text-brand-primary-button p-0 text-sm inline-flex items-center button-link-themed" onClick={() => navigate('/app/explore')}>
              Explore More Green Ideas & Events <ArrowRight size={14} className="ml-1" />
          </Button>
      </div>


      <AddTaskDialog
        isOpen={isAddTaskDialogOpen}
        onOpenChange={setIsAddTaskDialogOpen}
        onAddTask={handleAddTask}
        taskCategories={TASK_CATEGORIES}
        toast={toast}
      />
      
      {activeTasks.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold mb-3 text-brand-text">Active Tasks ({activeTasks.length})</h2>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <AnimatePresence>
              {activeTasks.map(task => (
                <TaskCard key={task.id} task={task} onToggleComplete={handleToggleComplete} />
              ))}
            </AnimatePresence>
          </motion.div>
        </section>
      )}
      
      {activeTasks.length === 0 && filteredTasks.length > 0 && filterStatus !== 'completed' && (
         <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8 px-4 bg-brand-primary-button/10 dark:bg-brand-primary-button/20 rounded-lg"
        >
          <CheckCircle size={48} className="mx-auto text-brand-primary-button mb-3" />
          <h2 className="text-2xl font-semibold text-brand-primary-button mb-2">All active tasks completed!</h2>
          <p className="text-brand-text opacity-80">Great job! Check your completed tasks or add new ones.</p>
        </motion.div>
      )}

      {filteredTasks.length === 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8 px-4 bg-slate-500/10 dark:bg-slate-500/20 rounded-lg"
        >
          <Zap size={48} className="mx-auto text-yellow-500 mb-3" />
          <h2 className="text-2xl font-semibold text-brand-text mb-2">No tasks match your filters!</h2>
          <p className="text-brand-text opacity-80">Try adjusting your filters or add new tasks to your sprint.</p>
        </motion.div>
      )}
      

      {completedTasks.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold mb-3 text-brand-text">Completed Tasks ({completedTasks.length})</h2>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <AnimatePresence>
              {completedTasks.map(task => (
                <TaskCard key={task.id} task={task} onToggleComplete={handleToggleComplete} />
              ))}
            </AnimatePresence>
          </motion.div>
        </section>
      )}
    </div>
  );
};

export default SprintQueueScreen;