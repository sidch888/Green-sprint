import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Compass, Zap, BookOpen, Droplets, Recycle, Library } from 'lucide-react';
import AppLogo from '@/components/icons/AppLogo';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

const placeholderCategories = [
  { name: "Energy Saving", icon: <Zap className="w-10 h-10 text-yellow-400" />, description: "Discover tips to reduce your energy consumption at home and work. Small changes, big impact!", color: "yellow", imageKey: "lightbulb-idea" },
  { name: "Sustainable Swaps", icon: <Compass className="w-10 h-10 text-blue-400" />, description: "Find eco-friendly alternatives for everyday products. From kitchen to bathroom, swap for sustainability.", color: "blue", imageKey: "reusable-bottles" },
  { name: "Learn & Grow", icon: <BookOpen className="w-10 h-10 text-purple-400" />, description: "Expand your knowledge on environmental topics. Understand climate change, biodiversity, and more.", color: "purple", imageKey: "open-book-nature" },
  { name: "Go Green", icon: <AppLogo size="sm" className="w-10 h-10 text-green-500" />, description: "Explore plant-based living, gardening tips, and ways to connect with nature for a healthier planet.", color: "green", imageKey: "seedling-hands" },
  { name: "Water Wise", icon: <Droplets className="w-10 h-10 text-sky-500" />, description: "Tips for conserving precious water resources in your daily life, from the tap to the garden.", color: "sky", imageKey: "water-drop-leaf" },
  { name: "Reduce & Reuse", icon: <Recycle className="w-10 h-10 text-orange-500" />, description: "Learn to minimize waste, recycle effectively, and embrace a circular economy mindset.", color: "orange", imageKey: "recycling-bins" },
];

const imageGallery = [
  { src: "https://umd-today.transforms.svdcdn.com/production/hero/IMG_9873_1920x1080.jpg?w=1440&h=810&auto=compress%2Cformat&fit=crop&dm=1651701271&s=4ee108f6f4a3a8a9ee39ebecd859623b", alt: "People in a forest setting", description: "Forest Bathing" },
  { src: "https://i0.wp.com/greensideup.ie/media/Autumn-Prep-at-Callan-Community-Garden-1024x742.jpg?resize=940%2C681", alt: "Community garden plot", description: "Gardening" },
  { src: "https://www.t-systems.com/resource/image/646008/ratio3x2/1440/960/ec36d74b1c34524cbdab5a92ae9575ec/153E4D87AAC365630EF0818A00905C55/im-sustainable-logistics-sustainable-retail.jpg", alt: "Sustainable shopping concept", description: "Sustainable Shopping" },
  { src: "https://developmenteducation.ie/wp-content/uploads/2017/04/Alternative_Energies.jpg", alt: "Wind turbines and solar panels", description: "Renewable Energy" },
  { src: "https://media.licdn.com/dms/image/v2/D4E12AQGvWrcct2GBHQ/article-cover_image-shrink_720_1280/article-cover_image-shrink_720_1280/0/1676535226711?e=2147483647&v=beta&t=qu4ilBjFrzRnqmQ-7RjscQab0KdJwMNzO49J1AoSpGo", alt: "Person riding a bicycle", description: "Eco-Friendly Commute" },
  { src: "https://detroitjustice.org/wp-content/uploads/2024/03/Community-Land-Trust-Session2.jpg", alt: "Community meeting or initiative", description: "Local Initiatives" },
];

const greenLibraryArticles = [
  { id: 1, title: "The Ultimate Guide to Composting at Home", category: "Waste Reduction", date: "2025-05-20", summary: "Learn how to turn your kitchen scraps into nutrient-rich compost for your garden. Reduces landfill waste and improves soil health.", icon: <Recycle className="w-6 h-6 text-orange-500 mr-2" /> },
  { id: 2, title: "10 Easy Ways to Save Water Every Day", category: "Water Conservation", date: "2025-05-18", summary: "Simple habits that can make a big difference in your water consumption and bills. Every drop counts towards a sustainable future.", icon: <Droplets className="w-6 h-6 text-sky-500 mr-2" /> },
  { id: 3, title: "Understanding Your Carbon Footprint", category: "Climate Action", date: "2025-05-15", summary: "What is a carbon footprint and how can you reduce yours? A beginner's guide to making impactful changes for the climate.", icon: <Zap className="w-6 h-6 text-yellow-400 mr-2" /> },
];

const ExploreScreen = () => {
  const [selectedCategory, setSelectedCategory] = useState(null);

  return (
    <div className="space-y-8 text-brand-text">
      <header className="text-center">
        <h1 className="text-3xl font-bold text-brand-text">
          Explore Eco Ideas
        </h1>
        <p className="text-md text-brand-text opacity-80 mt-2">
          Discover new ways to make a positive impact.
        </p>
      </header>
      
      <section>
        <h2 className="text-xl font-semibold mb-3 text-brand-text">Categories</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {placeholderCategories.map((category, index) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
              className={`p-3 rounded-xl bg-white/80 dark:bg-slate-800/80 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer flex flex-col items-center text-center h-full border-b-4 border-${category.color}-500 card-themed`}
              onClick={() => setSelectedCategory(category)}
            >
              {React.cloneElement(category.icon, { className: `w-8 h-8 text-${category.color}-500 mb-1.5`})}
              <h3 className={`text-xs sm:text-sm font-semibold text-${category.color}-700 dark:text-${category.color}-300`}>{category.name}</h3>
            </motion.div>
          ))}
        </div>
      </section>

      <AnimatePresence>
        {selectedCategory && (
          <Dialog open={!!selectedCategory} onOpenChange={() => setSelectedCategory(null)}>
            <DialogContent className="sm:max-w-md dialog-content-themed">
              <DialogHeader className="items-center pt-4">
                {React.cloneElement(selectedCategory.icon, { className: `w-12 h-12 text-${selectedCategory.color}-500 mb-2`})}
                <DialogTitle className={`text-xl text-center text-${selectedCategory.color}-600 dark:text-${selectedCategory.color}-400`}>{selectedCategory.name}</DialogTitle>
              </DialogHeader>
              <DialogDescription className="text-center text-sm text-muted-foreground px-4 py-1">
                {selectedCategory.description}
              </DialogDescription>
              <div className="mt-3 flex justify-center">
                <img  class="w-full max-w-[200px] h-auto rounded-lg shadow-md object-cover" alt={`${selectedCategory.name} illustrative image`} src="https://images.unsplash.com/photo-1684347417348-d261d03c60ef" />
              </div>
              <div className="mt-4 flex justify-end pb-4 px-4">
                <Button onClick={() => setSelectedCategory(null)} variant="outline" size="sm" className="text-brand-text border-brand-primary-button hover:bg-brand-primary-button/10">Close</Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </AnimatePresence>

      <section>
        <h2 className="text-xl font-semibold mb-3 text-brand-text">Inspiration Gallery</h2>
        <div className="grid grid-cols-2 gap-3">
          {imageGallery.map((image, index) => (
            <motion.div 
              key={image.src + index} 
              initial={{ opacity: 0, scale: 0.95 }} 
              animate={{ opacity: 1, scale: 1 }} 
              transition={{ delay: 0.1 + index * 0.05, duration: 0.4 }} 
              className="relative rounded-lg overflow-hidden shadow-md group aspect-square bg-slate-200 dark:bg-slate-700"
            >
              <img src={image.src} alt={image.alt} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
              <div className="absolute inset-0 bg-black/40 flex items-end p-2"> 
                <p className="text-white text-xs font-semibold line-clamp-2">{image.description}</p> 
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-3 text-brand-text flex items-center">
          <Library className="w-6 h-6 mr-2 text-brand-primary-button" /> Green Library
        </h2>
        <div className="space-y-4">
          {greenLibraryArticles.map((article, index) => (
            <motion.div
              key={article.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 + index * 0.1, duration: 0.3 }}
            >
              <Card className="flex flex-col card-themed shadow-lg hover:shadow-xl transition-shadow transform hover:-translate-y-0.5">
                <CardHeader className="pb-2 pt-4 px-4">
                  <div className="flex items-start mb-0.5">
                    {article.icon}
                    <CardTitle className="text-md leading-tight ml-1.5 text-brand-text">{article.title}</CardTitle>
                  </div>
                  <CardDescription className="text-xs ml-8 -mt-1 text-muted-foreground">{article.category} - {article.date}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow pt-0 pb-2 px-4">
                  <p className="text-sm text-brand-text opacity-90 line-clamp-2">{article.summary}</p>
                </CardContent>
                <div className="px-4 pb-3 pt-0">
                  <Button variant="link" className="text-brand-primary-button p-0 text-sm">Read More &rarr;</Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      <div className="text-center mt-10 py-6 bg-brand-primary-button/10 dark:bg-brand-primary-button/20 rounded-lg">
        <AppLogo size="md" className="mx-auto mb-2 opacity-75" />
        <p className="text-md text-brand-text">
          Stay tuned for more eco-inspiration!
        </p>
      </div>
    </div>
  );
};

export default ExploreScreen;