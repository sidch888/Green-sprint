import React from 'react';
import { motion } from 'framer-motion';
import AppLogo from '@/components/icons/AppLogo';

const SplashScreen = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center min-h-screen bg-brand-background text-brand-text fixed inset-0 z-50"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2, type: 'spring', stiffness: 120 }}
      >
        <AppLogo size="xl" className="mb-6 drop-shadow-lg" />
      </motion.div>
      <motion.h1 
        className="text-5xl font-bold mb-2 tracking-tight text-brand-text"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
        Green Sprint
      </motion.h1>
      <motion.p
        className="text-xl text-brand-text opacity-80"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.7, duration: 0.5 }}
      >
        Small actions, big impact.
      </motion.p>
    </motion.div>
  );
};

export default SplashScreen;