import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import AppLogo from '@/components/icons/AppLogo'; 
import { ChevronRight, CheckCircle, Target, Users } from 'lucide-react';

const onboardingSteps = [
  {
    icon: <AppLogo size="lg" className="mb-4" />,
    title: "Welcome to Green Sprint!",
    description: "Embark on your journey to a more sustainable lifestyle. Small actions, big impact.",
    image: "https://images.unsplash.com/photo-1582769923195-c67604809244?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fGVjb2xvZ3l8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60"
  },
  {
    icon: <Target size={48} className="mb-4 text-brand-primary-button" />,
    title: "Track Your Progress",
    description: "Log your daily eco-friendly tasks and see your positive impact grow over time.",
    image: "https://images.unsplash.com/photo-1506784983877-45594efa4c85?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fHByb2dyZXNzJTIwdHJhY2tpbmd8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60"
  },
  {
    icon: <Users size={48} className="mb-4 text-brand-primary-button" />,
    title: "Join a Community",
    description: "Connect with like-minded individuals, share tips, and inspire each other.",
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8Y29tbXVuaXR5fGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60"
  },
  {
    icon: <CheckCircle size={48} className="mb-4 text-brand-primary-button" />,
    title: "Ready to Start?",
    description: "Let's make a difference together. Your Green Sprint begins now!",
    image: "https://images.unsplash.com/photo-1518364538800-60f24f0969AF?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGdyZWVuJTIwbGlmZXN0eWxlfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60"
  }
];

const OnboardingScreen = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);

  const handleNext = () => {
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const { icon, title, description, image } = onboardingSteps[currentStep];

  return (
    <motion.div
      key={currentStep}
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-between min-h-screen p-6 bg-brand-background text-brand-text text-center"
    >
      <div className="flex-grow flex flex-col items-center justify-center w-full max-w-md">
        <div className="mb-8">
          {icon}
        </div>
        <img 
          src={image} 
          alt={title} 
          className="w-full h-48 object-cover rounded-lg mb-8 shadow-lg"
        />
        <h2 className="text-3xl font-bold mb-3">{title}</h2>
        <p className="text-md mb-12 opacity-80">{description}</p>
      </div>

      <div className="w-full max-w-md pb-6">
        <div className="flex justify-center mb-4">
          {onboardingSteps.map((_, index) => (
            <div
              key={index}
              className={`w-2.5 h-2.5 rounded-full mx-1 ${
                currentStep === index ? 'bg-brand-primary-button' : 'bg-slate-300 dark:bg-slate-600'
              }`}
            />
          ))}
        </div>
        <Button onClick={handleNext} className="w-full button-primary-themed py-3 text-lg">
          {currentStep === onboardingSteps.length - 1 ? "Get Started" : "Next"}
          <ChevronRight size={20} className="ml-2" />
        </Button>
        {currentStep < onboardingSteps.length - 1 && (
           <Button onClick={onComplete} variant="ghost" className="w-full mt-3 text-brand-text opacity-70 hover:text-brand-text">
             Skip
           </Button>
        )}
      </div>
    </motion.div>
  );
};

export default OnboardingScreen;