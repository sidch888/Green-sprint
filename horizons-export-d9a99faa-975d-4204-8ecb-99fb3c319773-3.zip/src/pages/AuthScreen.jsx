import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { LogIn, UserPlus, SkipForward } from 'lucide-react';
import AppLogo from '@/components/icons/AppLogo';
import GoogleLogo from '@/components/icons/GoogleLogo';
import AppleLogo from '@/components/icons/AppleLogo';
import DiscordLogo from '@/components/icons/DiscordLogo';
import { useToast } from "@/components/ui/use-toast";


const AuthScreen = ({ onAuthSuccess }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSignUp, setIsSignUp] = useState(false); 
  const [showSocialOptions, setShowSocialOptions] = useState(false);

  const handleSkip = () => {
    onAuthSuccess(); 
    navigate('/app');
  };

  const handleLogin = () => {
    toast({ title: "Login Clicked", description: "Login functionality to be implemented." });
  };

  const handleShowSignUpOptions = () => {
    setIsSignUp(true);
    setShowSocialOptions(true);
  };
  
  const handleShowLogin = () => {
    setIsSignUp(false);
    setShowSocialOptions(false);
  };

  const handleSocialSignUp = (provider) => {
    toast({ title: `Sign up with ${provider}`, description: `${provider} sign-up to be implemented.` });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center min-h-screen p-6 bg-brand-background"
    >
      <div className="w-full max-w-sm p-8 bg-brand-background rounded-xl shadow-2xl border border-slate-300 dark:border-slate-700">
        <div className="flex justify-center mb-6">
          <AppLogo size="lg" className="drop-shadow-lg" />
        </div>
        <h1 className="text-3xl font-bold text-center mb-2 text-brand-text">
          {showSocialOptions ? "Join Green Sprint" : "Welcome Back!"}
        </h1>
        <p className="text-center text-brand-text opacity-80 mb-8">
          {showSocialOptions ? "Create an account to save your progress." : "Login to continue your eco journey."}
        </p>

        {!showSocialOptions && (
          <motion.div 
            initial={{ opacity: 0, y:10 }}
            animate={{ opacity: 1, y:0 }}
            transition={{ duration: 0.3 }}
            className="space-y-4 mb-6"
          >
            <div>
              <Label htmlFor="email" className="text-brand-text">Email</Label>
              <Input id="email" type="email" placeholder="you@example.com" className="mt-1 bg-white dark:bg-slate-200 border-slate-300 dark:border-slate-600 text-brand-text placeholder:text-brand-text/60" />
            </div>
            <div>
              <Label htmlFor="password"className="text-brand-text">Password</Label>
              <Input id="password" type="password" placeholder="••••••••" className="mt-1 bg-white dark:bg-slate-200 border-slate-300 dark:border-slate-600 text-brand-text placeholder:text-brand-text/60" />
            </div>
            <Button onClick={handleLogin} className="w-full button-primary-themed">
              <LogIn size={18} className="mr-2" /> Login
            </Button>
            <p className="text-sm text-center text-brand-text opacity-80">
              Don't have an account?{' '}
              <button onClick={handleShowSignUpOptions} className="font-medium text-brand-primary-button hover:underline">
                Sign Up
              </button>
            </p>
          </motion.div>
        )}

        {showSocialOptions && (
          <motion.div 
            initial={{ opacity: 0, y:10 }}
            animate={{ opacity: 1, y:0 }}
            transition={{ duration: 0.3 }}
            className="space-y-3 mb-6"
          >
            <p className="text-sm font-medium text-center text-brand-text opacity-80 mb-3">Sign up with:</p>
            <Button onClick={() => handleSocialSignUp('Google')} variant="outline" className="w-full justify-start text-brand-text border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700">
              <GoogleLogo className="w-5 h-5 mr-3" /> Continue with Google
            </Button>
            <Button onClick={() => handleSocialSignUp('Apple')} variant="outline" className="w-full justify-start text-brand-text border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700">
              <AppleLogo className="w-5 h-5 mr-3" /> Continue with Apple
            </Button>
            <Button onClick={() => handleSocialSignUp('Discord')} variant="outline" className="w-full justify-start text-brand-text border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700">
              <DiscordLogo className="w-5 h-5 mr-3" /> Continue with Discord
            </Button>
             <p className="text-sm text-center text-brand-text opacity-80 pt-2">
              Already have an account?{' '}
              <button onClick={handleShowLogin} className="font-medium text-brand-primary-button hover:underline">
                Login
              </button>
            </p>
          </motion.div>
        )}
        
        <div className="mt-6 text-center">
          <Button onClick={handleSkip} className="button-skip-themed">
            <SkipForward size={16} className="mr-2" /> Skip for now
          </Button>
        </div>
      </div>
      <footer className="absolute bottom-4 text-center w-full text-brand-text opacity-70 text-xs">
        <p>&copy; {new Date().getFullYear()} Green Sprint. Small actions, big impact.</p>
      </footer>
    </motion.div>
  );
};

export default AuthScreen;