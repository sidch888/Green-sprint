import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import SplashScreen from '@/pages/SplashScreen';
import OnboardingScreen from '@/pages/OnboardingScreen';
import AuthScreen from '@/pages/AuthScreen';
import MainAppLayout from '@/layouts/MainAppLayout';
import SprintQueueScreen from '@/pages/app/SprintQueueScreen';
import ExploreScreen from '@/pages/app/ExploreScreen';
import DashboardScreen from '@/pages/app/DashboardScreen';
import ProfileScreen from '@/pages/app/ProfileScreen';
import { motion, AnimatePresence } from 'framer-motion';

const MOCK_TASKS_STORAGE_KEY = 'greenSprintTasks';
const USER_POINTS_STORAGE_KEY = 'greenSprintUserPoints';
const AUTH_STATUS_KEY = 'greenSprintAuthStatus';
const ONBOARDING_COMPLETE_KEY = 'onboardingComplete';

const MOCK_TASKS = [
  { id: '1', title: 'Swap plastic straw for metal one', category: 'Swaps', impact: 0.01, time: 5, completed: false, points: 10 },
  { id: '2', title: 'Tweet a climate petition', category: 'Advocacy', impact: 0.02, time: 5, completed: false, points: 15 },
  { id: '3', title: 'Try plant-based milk for a day', category: 'Lifestyle', impact: 0.05, time: 10, completed: false, points: 25 },
  { id: '4', title: 'Use a reusable shopping bag', category: 'Swaps', impact: 0.03, time: 2, completed: true, points: 10 },
  { id: '5', title: 'Shorten your shower by 2 minutes', category: 'Lifestyle', impact: 0.04, time: 2, completed: false, points: 20 },
  { id: '6', title: 'Unplug unused electronics', category: 'Energy', impact: 0.02, time: 3, completed: false, points: 15 },
];

const AppContent = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isOnboardingComplete, setIsOnboardingComplete] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    if (!localStorage.getItem(MOCK_TASKS_STORAGE_KEY)) {
      localStorage.setItem(MOCK_TASKS_STORAGE_KEY, JSON.stringify(MOCK_TASKS));
    }
    if (!localStorage.getItem(USER_POINTS_STORAGE_KEY)) {
      localStorage.setItem(USER_POINTS_STORAGE_KEY, JSON.stringify(0));
    }
    
    const authStatus = localStorage.getItem(AUTH_STATUS_KEY) === 'true';
    const onboardingStatus = localStorage.getItem(ONBOARDING_COMPLETE_KEY) === 'true';

    setIsAuthenticated(authStatus);
    setIsOnboardingComplete(onboardingStatus);
    
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2500); 

    return () => clearTimeout(timer);
  }, []);

  const handleSetAuthenticated = (status) => {
    localStorage.setItem(AUTH_STATUS_KEY, String(status));
    setIsAuthenticated(status);
  };

  const handleSetOnboardingComplete = () => {
    localStorage.setItem(ONBOARDING_COMPLETE_KEY, 'true');
    setIsOnboardingComplete(true);
  };

  if (isLoading) {
    return <SplashScreen />;
  }

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        {!isOnboardingComplete && <Route path="*" element={<Navigate to="/onboarding" replace />} />}
        <Route path="/onboarding" element={isOnboardingComplete ? <Navigate to="/auth" replace /> : <OnboardingScreen onComplete={handleSetOnboardingComplete} />} />
        
        <Route 
          path="/auth" 
          element={isAuthenticated ? <Navigate to="/app" replace /> : (isOnboardingComplete ? <AuthScreen onAuthSuccess={() => handleSetAuthenticated(true)} /> : <Navigate to="/onboarding" replace />)} 
        />
        
        <Route 
          path="/app" 
          element={isAuthenticated ? <MainAppLayout /> : <Navigate to="/auth" replace />}
        >
          <Route index element={<Navigate to="sprint" replace />} />
          <Route path="sprint" element={<SprintQueueScreen />} />
          <Route path="explore" element={<ExploreScreen />} />
          <Route path="dashboard" element={<DashboardScreen />} />
          <Route path="profile" element={<ProfileScreen onLogout={() => handleSetAuthenticated(false)} />} />
        </Route>
        
        {isOnboardingComplete && !isAuthenticated && <Route path="*" element={<Navigate to="/auth" replace />} />}
        {isOnboardingComplete && isAuthenticated && <Route path="*" element={<Navigate to="/app" replace />} />}
      </Routes>
    </AnimatePresence>
  );
};

function App() {
  return (
    <>
      <Router>
        <AppContent />
      </Router>
      <Toaster />
    </>
  );
}

export default App;