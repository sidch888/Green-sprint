
import React from 'react';
import { motion } from 'framer-motion';
import { UserCircle, Settings, Bell, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ProfileScreen = () => {
  const profileOptions = [
    { label: "Account Details", icon: <UserCircle className="w-5 h-5 mr-3 text-primary" /> },
    { label: "Notifications", icon: <Bell className="w-5 h-5 mr-3 text-yellow-500" /> },
    { label: "App Settings", icon: <Settings className="w-5 h-5 mr-3 text-blue-500" /> },
    { label: "Privacy & Security", icon: <Shield className="w-5 h-5 mr-3 text-red-500" /> },
  ];

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col items-center space-y-4 p-8 bg-gradient-to-br from-primary to-emerald-600 dark:from-primary/80 dark:to-emerald-600/80 rounded-xl shadow-xl text-center"
      >
        <div className="relative">
            <img  class="w-32 h-32 rounded-full border-4 border-white shadow-md object-cover" alt="User profile picture" src="https://images.unsplash.com/photo-1690721606848-ac5bdcde45ea" />
            <Button size="icon" variant="secondary" className="absolute bottom-0 right-0 rounded-full w-10 h-10 shadow-md">
              <Settings size={20} />
            </Button>
        </div>
        <h1 className="text-3xl font-bold text-white">Eco Warrior</h1>
        <p className="text-green-100">Joined: January 2025</p>
      </motion.div>

      <motion.div 
        className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.3 }}
      >
        <ul className="divide-y divide-slate-200 dark:divide-slate-700">
          {profileOptions.map((option, index) => (
            <motion.li
              key={option.label}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + index * 0.05, duration: 0.3 }}
              className="flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 cursor-pointer transition-colors first:rounded-t-lg last:rounded-b-lg"
            >
              <div className="flex items-center">
                {option.icon}
                <span className="text-slate-700 dark:text-slate-200">{option.label}</span>
              </div>
              <Settings size={18} className="text-slate-400 dark:text-slate-500" />
            </motion.li>
          ))}
        </ul>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.3 }}
        className="text-center"
      >
        <Button variant="destructive" size="lg" className="w-full md:w-auto">
          Log Out
        </Button>
      </motion.div>
      <footer className="text-center text-slate-500 dark:text-slate-400 text-sm pt-4">
        <p>&copy; {new Date().getFullYear()} Green Sprint. Manage your eco-journey.</p>
      </footer>
    </div>
  );
};

export default ProfileScreen;
  