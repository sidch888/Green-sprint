
import React from 'react';
import { motion } from 'framer-motion';
import { Compass, Zap, BookOpen } from 'lucide-react';

const placeholderCategories = [
  { name: "Energy Saving", icon: <Zap className="w-12 h-12 text-yellow-400 mx-auto mb-3" />, description: "Discover tips to reduce your energy consumption." },
  { name: "Sustainable Swaps", icon: <Compass className="w-12 h-12 text-blue-400 mx-auto mb-3" />, description: "Find eco-friendly alternatives for everyday products." },
  { name: "Learn & Grow", icon: <BookOpen className="w-12 h-12 text-purple-400 mx-auto mb-3" />, description: "Expand your knowledge on environmental topics." },
];

const ExploreScreen = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600 dark:from-blue-400 dark:to-purple-500">
        Explore Eco Ideas
      </h1>
      <p className="text-slate-600 dark:text-slate-300">
        Discover new ways to make a positive impact. More content coming soon!
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {placeholderCategories.map((category, index) => (
          <motion.div
            key={category.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, duration: 0.3 }}
            className="p-6 rounded-xl bg-white dark:bg-slate-800 shadow-lg hover:shadow-xl transition-shadow"
          >
            {category.icon}
            <h2 className="text-xl font-semibold text-center text-slate-800 dark:text-slate-100 mb-2">{category.name}</h2>
            <p className="text-sm text-center text-slate-500 dark:text-slate-400">{category.description}</p>
            <div className="mt-4 text-center">
               <span className="text-xs text-primary dark:text-green-400 font-semibold py-1 px-3 rounded-full bg-primary/10 dark:bg-green-400/10">
                Coming Soon
              </span>
            </div>
          </motion.div>
        ))}
      </div>
      <div className="text-center mt-10">
        <img  class="mx-auto w-full max-w-md rounded-lg shadow-md" alt="Illustration of diverse people collaborating on environmental solutions" src="https://images.unsplash.com/photo-1562106037-86f9aeadad80" />
        <p className="mt-4 text-slate-500 dark:text-slate-400">We're actively working on bringing you exciting new challenges and resources!</p>
      </div>
    </div>
  );
};

export default ExploreScreen;
  