
import React, { useState, useEffect } from 'react';
import TaskCard from '@/components/TaskCard';
import { Button } from '@/components/ui/button';
import { PlusCircle, Filter, CheckCircle, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';

const MOCK_TASKS_STORAGE_KEY = 'greenSprintTasks';

const SprintQueueScreen = () => {
  const [tasks, setTasks] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    const storedTasks = JSON.parse(localStorage.getItem(MOCK_TASKS_STORAGE_KEY) || '[]');
    setTasks(storedTasks);
  }, []);

  const updateStoredTasks = (updatedTasks) => {
    localStorage.setItem(MOCK_TASKS_STORAGE_KEY, JSON.stringify(updatedTasks));
    setTasks(updatedTasks);
  };

  const handleToggleComplete = (taskId) => {
    const updatedTasks = tasks.map(task =>
      task.id === taskId ? { ...task, completed: !task.completed } : task
    );
    updateStoredTasks(updatedTasks);
    const updatedTask = updatedTasks.find(t => t.id === taskId);
    toast({
      title: `Task ${updatedTask.completed ? "Completed" : "Marked Incomplete"}!`,
      description: `"${updatedTask.title}" status updated.`,
      variant: updatedTask.completed ? "default" : "destructive",
      className: updatedTask.completed ? "bg-green-500 border-green-500 text-white" : "bg-yellow-500 border-yellow-500 text-white"
    });
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const activeTasks = tasks.filter(task => !task.completed);
  const completedTasks = tasks.filter(task => task.completed);

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-green-500 to-emerald-700 dark:from-green-400 dark:to-emerald-600">
          Your Sprint
        </h1>
        <div className="space-x-2">
          <Button variant="outline" size="sm" className="bg-secondary hover:bg-secondary/80">
            <Filter size={16} className="mr-2" /> Filter
          </Button>
          <Button size="sm" className="bg-gradient-to-r from-primary to-emerald-600 hover:from-primary/90 hover:to-emerald-600/90 text-white">
            <PlusCircle size={16} className="mr-2" /> Add Task
          </Button>
        </div>
      </header>

      {activeTasks.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Active Tasks</h2>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            <AnimatePresence>
              {activeTasks.map(task => (
                <TaskCard key={task.id} task={task} onToggleComplete={handleToggleComplete} />
              ))}
            </AnimatePresence>
          </motion.div>
        </section>
      )}
      
      {activeTasks.length === 0 && tasks.length > 0 && (
         <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8 px-4 bg-green-50 dark:bg-green-900/20 rounded-lg"
        >
          <CheckCircle size={48} className="mx-auto text-primary mb-3" />
          <h2 className="text-2xl font-semibold text-primary mb-2">All tasks completed!</h2>
          <p className="text-slate-600 dark:text-slate-300">Great job on finishing your sprint! Ready for more?</p>
        </motion.div>
      )}

      {tasks.length === 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8 px-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg"
        >
          <Zap size={48} className="mx-auto text-yellow-500 mb-3" />
          <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-200 mb-2">No tasks yet!</h2>
          <p className="text-slate-600 dark:text-slate-300">Click "Add Task" to start your Green Sprint.</p>
        </motion.div>
      )}
      

      {completedTasks.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold mb-3 text-slate-700 dark:text-slate-200">Completed Tasks</h2>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            <AnimatePresence>
              {completedTasks.map(task => (
                <TaskCard key={task.id} task={task} onToggleComplete={handleToggleComplete} />
              ))}
            </AnimatePresence>
          </motion.div>
        </section>
      )}
    </div>
  );
};

export default SprintQueueScreen;
  