
import React from 'react';
import { motion } from 'framer-motion';
import { BarChartBig, TrendingUp, Target } from 'lucide-react';

const DashboardScreen = () => {
  const stats = [
    { label: "Tasks Completed", value: "12", icon: <BarChartBig className="w-8 h-8 text-primary" />, color: "green" },
    { label: "Impact Score", value: "1.35", icon: <TrendingUp className="w-8 h-8 text-blue-500" />, color: "blue" },
    { label: "Current Streak", value: "3 Days", icon: <Target className="w-8 h-8 text-yellow-500" />, color: "yellow" },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-yellow-500 to-orange-600 dark:from-yellow-400 dark:to-orange-500">
        Your Dashboard
      </h1>
      <p className="text-slate-600 dark:text-slate-300">
        Track your progress and achievements. More detailed stats coming soon!
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1, duration: 0.3 }}
            className={`p-6 rounded-xl bg-white dark:bg-slate-800 shadow-lg hover:shadow-xl transition-shadow border-l-4 border-${stat.color}-500`}
          >
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-lg font-semibold text-slate-700 dark:text-slate-200">{stat.label}</h2>
              {stat.icon}
            </div>
            <p className={`text-3xl font-bold text-${stat.color}-600 dark:text-${stat.color}-400`}>{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.3 }}
        className="p-6 rounded-xl bg-white dark:bg-slate-800 shadow-lg"
      >
        <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-3">Overall Progress</h2>
        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-6">
          <motion.div 
            className="bg-gradient-to-r from-primary to-emerald-500 h-6 rounded-full flex items-center justify-center text-xs font-medium text-white"
            initial={{ width: '0%'}}
            animate={{ width: '65%'}}
            transition={{ delay: 0.5, duration: 0.8, type: "spring" }}
          >
            65%
          </motion.div>
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">This is a placeholder progress bar. Actual data will be shown here.</p>
      </motion.div>
      <div className="text-center mt-10">
        <img  class="mx-auto w-full max-w-sm rounded-lg shadow-md" alt="Stylized chart showing environmental progress" src="https://images.unsplash.com/photo-1686061592689-312bbfb5c055" />
      </div>
    </div>
  );
};

export default DashboardScreen;
  