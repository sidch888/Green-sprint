
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Circle, Zap, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

const TaskCard = ({ task, onToggleComplete }) => {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.3 } },
  };

  return (
    <motion.div variants={cardVariants}>
      <Card className={`mb-4 overflow-hidden ${task.completed ? 'bg-green-50 dark:bg-green-900/30 border-green-300 dark:border-green-700' : 'bg-white dark:bg-slate-800 hover:shadow-green-200 dark:hover:shadow-green-700/30'}`}>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <CardTitle className={`text-lg ${task.completed ? 'line-through text-green-700 dark:text-green-500' : 'text-slate-800 dark:text-slate-100'}`}>
              {task.title}
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={() => onToggleComplete(task.id)} className="ml-2 -mt-2 -mr-2">
              {task.completed ? <CheckCircle className="h-6 w-6 text-primary" /> : <Circle className="h-6 w-6 text-slate-400 dark:text-slate-500" />}
            </Button>
          </div>
          <CardDescription className={`${task.completed ? 'text-green-600 dark:text-green-400' : 'text-slate-500 dark:text-slate-400'}`}>
            Category: {task.category}
          </CardDescription>
        </CardHeader>
        <CardContent className="pb-4 pt-0">
          <div className="flex items-center text-sm text-slate-600 dark:text-slate-300 mb-1">
            <Zap size={16} className="mr-2 text-yellow-500" />
            Impact: {task.impact} points
          </div>
          <div className="flex items-center text-sm text-slate-600 dark:text-slate-300">
            <Clock size={16} className="mr-2 text-blue-500" />
            Time: {task.time} min
          </div>
        </CardContent>
        {!task.completed && (
           <CardFooter className="p-0">
            <Button 
              onClick={() => onToggleComplete(task.id)}
              className="w-full rounded-none rounded-b-xl bg-gradient-to-r from-primary to-emerald-600 hover:from-primary/90 hover:to-emerald-600/90 text-white"
            >
              Mark as Complete
            </Button>
          </CardFooter>
        )}
      </Card>
    </motion.div>
  );
};

export default TaskCard;
  