
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import SplashScreen from '@/pages/SplashScreen';
import OnboardingScreen from '@/pages/OnboardingScreen';
import MainAppLayout from '@/layouts/MainAppLayout';
import SprintQueueScreen from '@/pages/app/SprintQueueScreen';
import ExploreScreen from '@/pages/app/ExploreScreen';
import DashboardScreen from '@/pages/app/DashboardScreen';
import ProfileScreen from '@/pages/app/ProfileScreen';
import { motion, AnimatePresence } from 'framer-motion';

const MOCK_TASKS_STORAGE_KEY = 'greenSprintTasks';
const MOCK_TASKS = [
  { id: '1', title: 'Swap plastic straw for metal one', category: 'Swaps', impact: '0.01', time: 5, completed: false },
  { id: '2', title: 'Tweet a climate petition', category: 'Advocacy', impact: '0.02', time: 5, completed: false },
  { id: '3', title: 'Try plant-based milk for a day', category: 'Lifestyle', impact: '0.05', time: 10, completed: false },
  { id: '4', title: 'Use a reusable shopping bag', category: 'Swaps', impact: '0.03', time: 2, completed: true },
  { id: '5', title: 'Shorten your shower by 2 minutes', category: 'Lifestyle', impact: '0.04', time: 2, completed: false },
  { id: '6', title: 'Unplug unused electronics', category: 'Energy', impact: '0.02', time: 3, completed: false },
];

if (!localStorage.getItem(MOCK_TASKS_STORAGE_KEY)) {
  localStorage.setItem(MOCK_TASKS_STORAGE_KEY, JSON.stringify(MOCK_TASKS));
}

function App() {
  return (
    <>
      <Router>
        <AnimatePresence mode="wait">
          <Routes>
            <Route path="/" element={<SplashScreen />} />
            <Route path="/onboarding" element={<OnboardingScreen />} />
            <Route path="/app" element={<MainAppLayout />}>
              <Route index element={<Navigate to="sprint" replace />} />
              <Route path="sprint" element={<SprintQueueScreen />} />
              <Route path="explore" element={<ExploreScreen />} />
              <Route path="dashboard" element={<DashboardScreen />} />
              <Route path="profile" element={<ProfileScreen />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AnimatePresence>
      </Router>
      <Toaster />
    </>
  );
}

export default App;
  