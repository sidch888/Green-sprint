
import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import BottomNavBar from '@/components/BottomNavBar';
import { motion, AnimatePresence } from 'framer-motion';

const MainAppLayout = () => {
  const location = useLocation();

  return (
    <div className="flex flex-col min-h-screen bg-slate-100 dark:bg-slate-900">
      <main className="flex-grow container mx-auto px-4 py-6 pb-24 md:pb-6"> {/* Added padding-bottom for mobile nav */}
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="w-full"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>
      <BottomNavBar />
    </div>
  );
};

export default MainAppLayout;
  